## Level 4 Free-Python-games 内容复现

### 1.内容简介

​		Free-python-games 是一个汇聚了多款小游戏的开源项目。本实验基于此开源项目进行了复现。



### 2.复现说明

​		复现的过程中，针对部分包导入进行了修改，保证了程序的可执行性。我对**所有**的小游戏进行了逐一测试，保证了其可行性与可玩性。

#### ant.py：蚂蚁行为仿真

​		这是一个可以模拟蚂蚁运动行为的程序。运行程序后，在打开的窗口界面中会生成一个黑色像素点（蚂蚁）。每一时刻它都会随机移动一段距离，并旋转一定角度。除此之外貌似也就没有什么特殊的了......

```Python
"""Ant, simple animation demo.

Exercises

1. Wrap ant around screen boundaries.
2. Make the ant leave a trail.
3. Change the ant color based on position.
   Hint: colormode(255); color(0, 100, 200)
"""

import random 
import turtle 
from utils import vector

ant = vector(0, 0)
aim = vector(2, 0)


def wrap(value):
    """Wrap value around -200 and 200."""
    return value  # TODO


def draw():
    """Move ant and draw screen."""
    ant.move(aim)
    ant.x = wrap(ant.x)
    ant.y = wrap(ant.y)

    aim.move(random.random() - 0.5)		# 随机移动 -0.5 ~ 0.5 单位长度
    aim.rotate(random.random() * 10 - 5)	# 随机旋转 -5° ~ 5°

    turtle.clear()
    turtle.goto(ant.x, ant.y)
    turtle.dot(5)

    turtle.ontimer(draw, 100)		# 每 100 ms 调用一次绘图函数


turtle.setup(420, 420, 370, 0)
turtle.hideturtle()
turtle.tracer(False)
turtle.up()
draw()
turtle.done()
```

​		程序演示效果如下：

<img src="pics\ants.png" alt="image-20220531141342721" style="zoom:67%;" />



#### bagels.py 经典数字推理游戏

​		数字推理游戏的基本思路是：对于未知的三位数，玩家可以通过逐次尝试法去获取其可能的信息。每一次得到的信息包括：某一个数字正确、某一个数字正确且位置正确、所有数字均错误。根据有限的信息，玩家需要更改自己的猜测，并在规定的次数内得到最终结果。

​		相比编程而言，可能玩游戏本身更难一点。

```python
"""Bagels, a number puzzle game.

Exercises:

1. Can you guess the number?
2. How much harder is 6 digits? Do you need more guesses?
3. What's the maximum number of digits we could support?

Adapted from code in https://inventwithpython.com/chapter11.html
"""

from random import sample, shuffle

digits = 3
guesses = 10

print('I am thinking of a', digits, 'digit number.')
print('Try to guess what it is.')
print('Here are some clues:')
print('When I say:    That means:')
print('  pico         One digit is correct but in the wrong position.')
print('  fermi        One digit is correct and in the right position.')
print('  bagels       No digit is correct.')
print('There are no repeated digits in the number.')

# Create a random number.

letters = sample('0123456789', digits)

if letters[0] == '0':
    letters.reverse()

number = ''.join(letters)

print('I have thought up a number.')
print('You have', guesses, 'guesses to get it.')

counter = 1

while True:
    print('Guess #', counter)
    guess = input()

    if len(guess) != digits:
        print('Wrong number of digits. Try again!')
        continue

    # Create the clues.

    clues = []

    for index in range(digits):
        if guess[index] == number[index]:
            clues.append('fermi')
        elif guess[index] in number:
            clues.append('pico')

    shuffle(clues)

    if len(clues) == 0:
        print('bagels')
    else:
        print(' '.join(clues))

    counter += 1

    if guess == number:
        print('You got it!')
        break

    if counter > guesses:
        print('You ran out of guesses. The answer was', number)
        break

```

​		某一次的游戏过程如下：

```python
I am thinking of a 3 digit number.
Try to guess what it is.
Here are some clues:
When I say:    That means:
  pico         One digit is correct but in the wrong position.
  fermi        One digit is correct and in the right position.
  bagels       No digit is correct.
There are no repeated digits in the number.
I have thought up a number.
You have 10 guesses to get it.
Guess # 1
123
pico
Guess # 2
234
fermi fermi
Guess # 3
534
fermi fermi
Guess # 4
634
fermi fermi
Guess # 5
734
fermi fermi fermi
You got it!
```



#### bounce.py 弹球模拟器

​		一个物理模拟器。打开界面后，一个黑色的小球会在场地中一直运动。它会以窗口边界为墙体进行弹性碰撞，从而实现在窗口中的往复运动。不过目前没有玩家操控的内容。

```python
"""Bounce, a simple animation demo.

Exercises

1. Make the ball speed up and down.
2. Change how the ball bounces when it hits a wall.
3. Make the ball leave a trail.
4. Change the ball color based on position.
   Hint: colormode(255); color(0, 100, 200)
"""

import random 
import turtle 
from utils import vector


def value():
    """Randomly generate value between (-5, -3) or (3, 5)."""
    return (3 + random.random() * 2) * random.choice([1, -1])


ball = vector(0, 0)
aim = vector(value(), value())


def draw():
    """Move ball and draw game."""
    ball.move(aim)

    x = ball.x
    y = ball.y

    if x < -200 or x > 200:
        aim.x = -aim.x

    if y < -200 or y > 200:
        aim.y = -aim.y

    turtle.clear()
    turtle.goto(x, y)
    turtle.dot(10)

    turtle.ontimer(draw, 50)


turtle.setup(420, 420, 370, 0)
turtle.hideturtle()
turtle.tracer(False)
turtle.up()
draw()
turtle.done()
```

​		一个平平无奇的界面。

<img src="pics\bounce.png" alt="image-20220531142649682" style="zoom:67%;" />



#### cannon.py 加农炮之战

​		在这个小游戏中，用户需要通过鼠标操控屏幕左下角的加农炮发射炮弹（红色像素点），同时屏幕右侧会随机生成大量蓝色目标缓缓向左移动。游戏的核心便是尽可能击中这些目标。

```python
"""Cannon, hitting targets with projectiles.

Exercises

1. Keep score by counting target hits.
2. Vary the effect of gravity.
3. Apply gravity to the targets.
4. Change the speed of the ball.
"""

from random import randrange
import turtle
from utils import vector

ball = vector(-200, -200)
speed = vector(0, 0)
targets = []


def tap(x, y):
    """Respond to screen tap."""
    if not inside(ball):
        ball.x = -199
        ball.y = -199
        speed.x = (x + 200) / 25
        speed.y = (y + 200) / 25


def inside(xy):
    """Return True if xy within screen."""
    return -200 < xy.x < 200 and -200 < xy.y < 200


def draw():
    """Draw ball and targets."""
    turtle.clear()

    for target in targets:
        turtle.goto(target.x, target.y)
        turtle.dot(20, 'blue')

    if inside(ball):
        turtle.goto(ball.x, ball.y)
        turtle.dot(6, 'red')

    turtle.update()


def move():
    """Move ball and targets."""
    if randrange(40) == 0:
        y = randrange(-150, 150)	# 随机生成蓝色目标的纵坐标
        target = vector(200, y)
        targets.append(target)

    for target in targets:
        target.x -= 0.5

    if inside(ball):
        speed.y -= 0.35
        ball.move(speed)

    dupe = targets.copy()
    targets.clear()

    for target in dupe:
        if abs(target - ball) > 13:
            targets.append(target)

    draw()

    for target in targets:
        if not inside(target):
            return

    turtle.ontimer(move, 30)


turtle.setup(420, 420, 370, 0)
turtle.hideturtle()
turtle.up()
turtle.tracer(False)
turtle.onscreenclick(tap)
move()
turtle.done()
```





<img src="pics\cannon.png" alt="image-20220531142959227" style="zoom:67%;" />



#### connetc.py 四子棋

​		这是一个双人小游戏。和五子棋的规则类似，四子棋要求任意一名玩家的四个棋子按横竖斜的任何方式排成一排即可取得胜利。但不同的是，本游戏的棋盘处于竖直平面内。玩家只能在现有棋子的上方或最下面一排落子。这样的设定在一定程度上增强了游戏的策略性。

​		然而目前的程序还十分简陋：没有胜利判定、没有边界限制。以下是程序实现与测试示例图。

```python
"""Connect Four

Exercises

1. Change the colors.
2. Draw squares instead of circles for open spaces.
3. Add logic to detect a full row.
4. Create a random computer player.
5. How would you detect a winner?
"""

import turtle
from utils import line

turns = {'red': 'yellow', 'yellow': 'red'}
state = {'player': 'yellow', 'rows': [0] * 8}


def grid():
    """Draw Connect Four grid."""
    turtle.bgcolor('light blue')

    for x in range(-150, 200, 50):
        line(x, -200, x, 200)

    for x in range(-175, 200, 50):
        for y in range(-175, 200, 50):
            turtle.up()
            turtle.goto(x, y)
            turtle.dot(40, 'white')

    turtle.update()


def tap(x, y):
    """Draw red or yellow circle in tapped row."""
    player = state['player']
    rows = state['rows']

    row = int((x + 200) // 50)
    count = rows[row]

    x = ((x + 200) // 50) * 50 - 200 + 25
    y = count * 50 - 200 + 25

    turtle.up()
    turtle.goto(x, y)
    turtle.dot(40, player)
    turtle.update()

    rows[row] = count + 1
    state['player'] = turns[player]


turtle.setup(420, 420, 370, 0)
turtle.hideturtle()
turtle.tracer(False)
grid()
turtle.onscreenclick(tap)
turtle.done()
```



<img src="pics\connect.png" alt="image-20220531144127271" style="zoom:50%;" />





#### crypto.py 加密解密程序

​		这个程序为用户提供了基于凯撒密码的加密解密工具。凯撒密码的核心是对所有的字母进行移位对应，因此至多有 26 种加密方式。根据密钥（移位量）的不同，加密解密的结果也不同。

```python
"""Crypto: tool for encrypting and decrypting messages.

Exercises

1. Review 'ord' and 'chr' functions and letter-to-number mapping.
2. Explain what happens if you use key 26.
3. Find a way to decode a message without a key.
4. Encrypt numbers.
5. Make the encryption harder to decode.

Adapted from code in https://inventwithpython.com/chapter14.html
"""


def encrypt(message, key):
    """Encrypt message with key."""
    result = ''

    # Iterate letters in message and encrypt each individually.

    for letter in message:
        if letter.isalpha():

            # Letters are numbered like so:
            # A, B, C - Z is 65, 66, 67 - 90
            # a, b, c - z is 97, 98, 99 - 122

            num = ord(letter)

            if letter.isupper():
                base = ord('A')
            else:
                assert letter.islower()
                base = ord('a')

            # The encryption equation:

            num = (num - base + key) % 26 + base

            result += chr(num)

        elif letter.isdigit():

            # TODO: Encrypt digits.
            result += letter

        else:
            result += letter

    return result


def decrypt(message, key):
    """Decrypt message with key."""
    return encrypt(message, -key)


def decode(message):
    """Decode message without key."""
    pass  # TODO


def get_key():
    """Get key from user."""
    try:
        text = input('Enter a key (1 - 25): ')
        key = int(text)
        return key
    except Exception:
        print('Invalid key. Using key: 0.')
        return 0


print('Do you wish to encrypt, decrypt, or decode a message?')
choice = input()

if choice == 'encrypt':
    phrase = input('Message: ')
    code = get_key()
    print('Encrypted message:', encrypt(phrase, code))
elif choice == 'decrypt':
    phrase = input('Message: ')
    code = get_key()
    print('Decrypted message:', decrypt(phrase, code))
elif choice == 'decode':
    phrase = input('Message: ')
    print('Decoding message:')
    decode(phrase)
else:
    print('Error: Unrecognized Command')

```

​		一个简单的测试：

```python
Do you wish to encrypt, decrypt, or decode a message?
encrypt
Message: hello world!
Enter a key (1 - 25): 5
Encrypted message: mjqqt btwqi!


Do you wish to encrypt, decrypt, or decode a message?
decrypt
Message: mjqqt btwqi!
Enter a key (1 - 25): 5
Decrypted message: hello world!
```





#### fidget.py 指尖陀螺模拟器

​		这个小游戏模拟了一个简单的指尖陀螺。用户只需要按下空格键即可为其加速。连续按动空格键，指尖陀螺将加速旋转；而一段时间不按动空格键，指尖陀螺会缓缓停止。

```python
"""Fidget, inspired by fidget spinners.

Exercises

1. Change the spinner pattern.
2. Respond to mouse clicks.
3. Change its acceleration.
4. Make it go forwards and backwards.
"""

import turtle
state = {'turn': 0}


def spinner():
    """Draw fidget spinner."""
    turtle.clear()
    angle = state['turn'] / 10
    turtle.right(angle)
    turtle.forward(100)
    turtle.dot(120, 'red')
    turtle.back(100)
    turtle.right(120)
    turtle.forward(100)
    turtle.dot(120, 'green')
    turtle.back(100)
    turtle.right(120)
    turtle.forward(100)
    turtle.dot(120, 'blue')
    turtle.back(100)
    turtle.right(120)
    turtle.update()


def animate():
    """Animate fidget spinner."""
    if state['turn'] > 0:
        state['turn'] -= 1

    spinner()
    turtle.ontimer(animate, 20)


def flick():
    """Flick fidget spinner."""
    state['turn'] += 10


turtle.setup(420, 420, 370, 0)
turtle.hideturtle()
turtle.tracer(False)
turtle.width(20)
turtle.onkey(flick, 'space')
turtle.listen()
animate()
turtle.done()
```



<img src="pics\fidget.png" alt="image-20220531145131013" style="zoom: 50%;" />





#### flappy.py 飞翔鸟

​		经典的 Flappy Bird 游戏改编。现在玩家操控的不是小鸟而是小球。每一次单击会让小球向上移动一段距离，随后自由落下。玩家需要合理控制单击的时机以躲避障碍物。

```python
"""Flappy, game inspired by Flappy Bird.

Exercises

1. Keep score.
2. Vary the speed.
3. Vary the size of the balls.
4. Allow the bird to move forward and back.
"""

import random
import turtle
from utils import vector

bird = vector(0, 0)
balls = []


def tap(x, y):
    """Move bird up in response to screen tap."""
    up = vector(0, 50)
    bird.move(up)


def inside(point):
    """Return True if point on screen."""
    return -200 < point.x < 200 and -200 < point.y < 200


def draw(alive):
    """Draw screen objects."""
    turtle.clear()

    turtle.goto(bird.x, bird.y)

    if alive:
        turtle.dot(10, 'green')
    else:
        turtle.dot(10, 'red')

    for ball in balls:
        turtle.goto(ball.x, ball.y)
        turtle.dot(20, 'black')

    turtle.update()


def move():
    """Update object positions."""
    bird.y -= 5

    for ball in balls:
        ball.x -= 3

    if random.randrange(10) == 0:
        y = random.randrange(-199, 199)
        ball = vector(199, y)
        balls.append(ball)

    while len(balls) > 0 and not inside(balls[0]):
        balls.pop(0)

    if not inside(bird):
        draw(False)
        return

    for ball in balls:
        if abs(ball - bird) < 15:
            draw(False)
            return

    draw(True)
    turtle.ontimer(move, 50)


turtle.setup(420, 420, 370, 0)
turtle.hideturtle()
turtle.up()
turtle.tracer(False)
turtle.onscreenclick(tap)
move()
turtle.done()
```



<img src="D:\0-Programmingformelon\python\pics\flappy.png" alt="image-20220531145826906" style="zoom:50%;" />





#### guess.py 猜数字

​		根据大小猜数字。二分查找的启蒙制作（

```python
"""Guess a number within a range.

Exercises

1. Change the range to be from 0 to 1,000,000.
2. Can you still guess the number?
3. Print the number of guesses made.
4. Limit the number of guesses to the minimum required.
"""

from random import randint

start = 1
end = 100
value = randint(start, end)

# print(value)
print("I'm thinking of a number between", start, 'and', end)

guess = None

while guess != value:
    text = input('Guess the number: ')
    guess = int(text)

    if guess < value:
        print('Higher.')
    elif guess > value:
        print('Lower.')

print('Congratulations! You guessed the right answer:', value)
```

​		一次尝试如下：

```
I'm thinking of a number between 1 and 100
Guess the number: 55
Higher.
Guess the number: 77
Higher.
Guess the number: 99
Lower.
Guess the number: 80
Higher.
Guess the number: 90
Higher.
Guess the number: 95
Higher.
Guess the number: 98
Congratulations! You guessed the right answer: 98
```





#### life.py 生命游戏

​		生命游戏是英国数学家 John Conway 在 1970 年发明的细胞自动机。在一个二维点状平面上， 每一个点遵循如下规则：

1. 少于2个邻居的点，在下一回合死去。模拟生命较少的情况。
2. 在周围邻居数量是2和3时，下一回合保持不变
3. 在周围邻居数量大于3时，下一回合死去，模拟生命拥挤的情况。
4. 当一个空白的点，周围的邻居数量是3个是， 下一回合将会产生一个新的点。模拟繁殖。

尽管底层规则十分简单，但生命游戏的演化结果却包罗万象。事实上，我们可以用生命游戏来搭建一台计算机，从而模拟一切行为。

```python
"""Game of Life simulation.

Conway's game of life is a classic cellular automation created in 1970 by John
Conway. https://en.wikipedia.org/wiki/Conway%27s_Game_of_Life

Exercises

1. Can you identify any Still Lifes, Oscillators, or Spaceships?
2. How can you make the simulation faster? Or bigger?
3. How would you modify the initial state?
4. Try changing the rules of life :)
"""

from random import choice
import turtle
from utils import square

cells = {}


def initialize():
    """Randomly initialize the cells."""
    for x in range(-200, 200, 10):
        for y in range(-200, 200, 10):
            cells[x, y] = False

    for x in range(-50, 50, 10):
        for y in range(-50, 50, 10):
            cells[x, y] = choice([True, False])


def step():
    """Compute one step in the Game of Life."""
    neighbors = {}

    for x in range(-190, 190, 10):
        for y in range(-190, 190, 10):
            count = -cells[x, y]
            for h in [-10, 0, 10]:
                for v in [-10, 0, 10]:
                    count += cells[x + h, y + v]
            neighbors[x, y] = count

    for cell, count in neighbors.items():
        if cells[cell]:
            if count < 2 or count > 3:
                cells[cell] = False
        elif count == 3:
            cells[cell] = True


def draw():
    """Draw all the squares."""
    step()
    turtle.clear()
    for (x, y), alive in cells.items():
        color = 'green' if alive else 'black'
        square(x, y, 10, color)
    turtle.update()
    turtle.ontimer(draw, 100)


turtle.setup(420, 420, 370, 0)
turtle.hideturtle()
turtle.tracer(False)
initialize()
draw()
turtle.done()
```



<img src="pics\life.png" alt="image-20220531150225545" style="zoom:50%;" />



#### madlib.py 故事制造机

​		这是一个荒诞故事生成器。程序根据用户输入的单词生成一个无厘头的句子。或许多人游戏时这个更加有趣。

```python
"""Mad Libs: Funny Story Creation Game

Exercises:

1. How to replace the story?
2. How load the story and from a file?
3. How to add additional parts of speech?
"""

# The quick brown fox jumps over the lazy dog.
template = 'The |1| |2| |3| |4| over the |5| |6|.'
parts = {
    '1': 'adjective',
    '2': 'adjective',
    '3': 'noun',
    '4': 'verb',
    '5': 'adjective',
    '6': 'noun',
}

chunks = []

for chunk in template.split('|'):
    if chunk in parts:
        description = parts[chunk]
        prompt = 'Enter [{}]: '.format(description)
        word = input(prompt)
        chunks.append(word)
    else:
        chunks.append(chunk)

print('=' * 80)
story = ''.join(chunks)
print(story)

```

​		一次测试如下：

```
Enter [adjective]: happy
Enter [adjective]: fast
Enter [noun]: apple
Enter [verb]: throw
Enter [adjective]: funny
Enter [noun]: tree
================================================================================
The happy fast apple throw over the funny tree.
```



#### maze.py 迷宫游戏

​		这是一个简单的迷宫小游戏。玩家可以通过单击绘制路径。游戏目标是穿过迷宫，不过目前并没有一种检测方式......

```python
"""Maze, move from one side to another.

Excercises

1. Keep score by counting taps.
2. Make the maze harder.
3. Generate the same maze twice.
"""

from random import random
import turtle
from utils import line


def draw():
    """Draw maze."""
    turtle.color('black')
    turtle.width(5)

    for x in range(-200, 200, 40):
        for y in range(-200, 200, 40):
            if random() > 0.5:
                line(x, y, x + 40, y + 40)
            else:
                line(x, y + 40, x + 40, y)

    turtle.update()


def tap(x, y):
    """Draw line and dot for screen tap."""
    if abs(x) > 198 or abs(y) > 198:
        turtle.up()
    else:
        turtle.down()

    turtle.width(2)
    turtle.color('red')
    turtle.goto(x, y)
    turtle.dot(4)


turtle.setup(420, 420, 370, 0)
turtle.hideturtle()
turtle.tracer(False)
draw()
turtle.onscreenclick(tap)
turtle.done()
```



<img src="pics\maze.png" alt="image-20220531151205008" style="zoom:50%;" />





#### memory.py 记忆力游戏

​		一个记忆力小游戏。玩家需要根据翻出的数字位置进行匹配。界面中一共有 1~32 32种数字、64个数字方格。这个游戏整体单独不大，但还是比较花费时间的。

```python
"""Memory, puzzle game of number pairs.

Exercises:

1. Count and print how many taps occur.
2. Decrease the number of tiles to a 4x4 grid.
3. Detect when all tiles are revealed.
4. Center single-digit tile.
5. Use letters instead of tiles.
"""


import turtle
import random
from utils import path

car = path('car.gif')
tiles = list(range(32)) * 2
state = {'mark': None}
hide = [True] * 64


def square(x, y):
    """Draw white square with black outline at (x, y)."""
    turtle.up()
    turtle.goto(x, y)
    turtle.down()
    turtle.color('black', 'white')
    turtle.begin_fill()
    for count in range(4):
        turtle.forward(50)
        turtle.left(90)
    turtle.end_fill()


def index(x, y):
    """Convert (x, y) coordinates to tiles index."""
    return int((x + 200) // 50 + ((y + 200) // 50) * 8)


def xy(count):
    """Convert tiles count to (x, y) coordinates."""
    return (count % 8) * 50 - 200, (count // 8) * 50 - 200


def tap(x, y):
    """Update mark and hidden tiles based on tap."""
    spot = index(x, y)
    mark = state['mark']

    if mark is None or mark == spot or tiles[mark] != tiles[spot]:
        state['mark'] = spot
    else:
        hide[spot] = False
        hide[mark] = False
        state['mark'] = None


def draw():
    """Draw image and tiles."""
    turtle.clear()
    turtle.goto(0, 0)
    turtle.shape(car)
    turtle.stamp()

    for count in range(64):
        if hide[count]:
            x, y = xy(count)
            square(x, y)

    mark = state['mark']

    if mark is not None and hide[mark]:
        x, y = xy(mark)
        turtle.up()
        turtle.goto(x + 2, y)
        turtle.color('black')
        turtle.write(tiles[mark], font=('Arial', 30, 'normal'))

    turtle.update()
    turtle.ontimer(draw, 100)


random.shuffle(tiles)
turtle.setup(420, 420, 370, 0)
turtle.addshape(car)
turtle.hideturtle()
turtle.tracer(False)
turtle.onscreenclick(tap)
draw()
turtle.done()
```



<img src="pics\memory.png" alt="image-20220531151940760" style="zoom:50%;" />





#### minesweeper.py 扫雷

​		经典游戏。不过这里的实现效果比较一般。

```python
"""Minesweeper

Exercises

1. What does the `seed(0)` function call do?
2. Change the number of bombs on the grid.
3. Change the size of the grid.
"""

from random import randrange, seed
import turtle
from utils import floor, square

seed(0)
bombs = {}
shown = {}
counts = {}


def initialize():
    """Initialize `bombs`, `counts`, and `shown` grids."""
    for x in range(-250, 250, 50):
        for y in range(-250, 250, 50):
            bombs[x, y] = False
            shown[x, y] = False
            counts[x, y] = -1

    for count in range(8):
        x = randrange(-200, 200, 50)
        y = randrange(-200, 200, 50)
        bombs[x, y] = True

    for x in range(-200, 200, 50):
        for y in range(-200, 200, 50):
            total = 0
            for i in (-50, 0, 50):
                for j in (-50, 0, 50):
                    total += bombs[x + i, y + j]
            counts[x, y] = total


def stamp(x, y, text):
    """Display `text` at coordinates `x` and `y`."""
    square(x, y, 50, 'white')
    turtle.color('black')
    turtle.write(text, font=('Arial', 50, 'normal'))


def draw():
    """Draw the initial board grid."""
    for x in range(-200, 200, 50):
        for y in range(-200, 200, 50):
            stamp(x, y, '?')


def end():
    """Draw the bombs as X's on the grid."""
    for x in range(-200, 200, 50):
        for y in range(-200, 200, 50):
            if bombs[x, y]:
                stamp(x, y, 'X')


def tap(x, y):
    """Respond to screen click at `x` and `y` coordinates."""
    x = floor(x, 50)
    y = floor(y, 50)

    if bombs[x, y]:
        end()
        return

    pairs = [(x, y)]

    while pairs:
        x, y = pairs.pop()
        stamp(x, y, counts[x, y])
        shown[x, y] = True

        if counts[x, y] == 0:
            for i in (-50, 0, 50):
                for j in (-50, 0, 50):
                    pair = x + i, y + j
                    if not shown[pair]:
                        pairs.append(pair)


turtle.setup(420, 420, 370, 0)
turtle.hideturtle()
turtle.tracer(False)
initialize()
draw()
turtle.onscreenclick(tap)
turtle.done()
```



<img src="pics\minesweeper.png" alt="image-20220531152749050" style="zoom:50%;" />





#### pacman.py 吃豆人

​		经典游戏。但是 Goast 是随机游走的 emmmmm

```python
"""Pacman, classic arcade game.

Exercises

1. Change the board.
2. Change the number of ghosts.
3. Change where pacman starts.
4. Make the ghosts faster/slower.
5. Make the ghosts smarter.
"""

from random import choice
import turtle
from utils import floor, vector

state = {'score': 0}
path = turtle.Turtle(visible=False)
writer = turtle.Turtle(visible=False)
aim = vector(5, 0)
pacman = vector(-40, -80)
ghosts = [
    [vector(-180, 160), vector(5, 0)],
    [vector(-180, -160), vector(0, 5)],
    [vector(100, 160), vector(0, -5)],
    [vector(100, -160), vector(-5, 0)],
]
# fmt: off
tiles = [
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
    0, 1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
    0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 0, 0, 0, 0,
    0, 1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
    0, 1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0,
    0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0,
    0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 0, 0, 0, 0,
    0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
]
# fmt: on


def square(x, y):
    """Draw square using path at (x, y)."""
    path.up()
    path.goto(x, y)
    path.down()
    path.begin_fill()

    for count in range(4):
        path.forward(20)
        path.left(90)

    path.end_fill()


def offset(point):
    """Return offset of point in tiles."""
    x = (floor(point.x, 20) + 200) / 20
    y = (180 - floor(point.y, 20)) / 20
    index = int(x + y * 20)
    return index


def valid(point):
    """Return True if point is valid in tiles."""
    index = offset(point)

    if tiles[index] == 0:
        return False

    index = offset(point + 19)

    if tiles[index] == 0:
        return False

    return point.x % 20 == 0 or point.y % 20 == 0


def world():
    """Draw world using path."""
    turtle.bgcolor('black')
    path.color('blue')

    for index in range(len(tiles)):
        tile = tiles[index]

        if tile > 0:
            x = (index % 20) * 20 - 200
            y = 180 - (index // 20) * 20
            square(x, y)

            if tile == 1:
                path.up()
                path.goto(x + 10, y + 10)
                path.dot(2, 'white')


def move():
    """Move pacman and all ghosts."""
    writer.undo()
    writer.write(state['score'])

    turtle.clear()

    if valid(pacman + aim):
        pacman.move(aim)

    index = offset(pacman)

    if tiles[index] == 1:
        tiles[index] = 2
        state['score'] += 1
        x = (index % 20) * 20 - 200
        y = 180 - (index // 20) * 20
        square(x, y)

    turtle.up()
    turtle.goto(pacman.x + 10, pacman.y + 10)
    turtle.dot(20, 'yellow')

    for point, course in ghosts:
        if valid(point + course):
            point.move(course)
        else:
            options = [
                vector(5, 0),
                vector(-5, 0),
                vector(0, 5),
                vector(0, -5),
            ]
            plan = choice(options)
            course.x = plan.x
            course.y = plan.y

        turtle.up()
        turtle.goto(point.x + 10, point.y + 10)
        turtle.dot(20, 'red')

    turtle.update()

    for point, course in ghosts:
        if abs(pacman - point) < 20:
            return

    turtle.ontimer(move, 100)


def change(x, y):
    """Change pacman aim if valid."""
    if valid(pacman + vector(x, y)):
        aim.x = x
        aim.y = y


turtle.setup(420, 420, 370, 0)
turtle.hideturtle()
turtle.tracer(False)
writer.goto(160, 160)
writer.color('white')
writer.write(state['score'])
turtle.listen()
turtle.onkey(lambda: change(5, 0), 'Right')
turtle.onkey(lambda: change(-5, 0), 'Left')
turtle.onkey(lambda: change(0, 5), 'Up')
turtle.onkey(lambda: change(0, -5), 'Down')
world()
move()
turtle.done()
```



<img src="pics\pacman.png" alt="image-20220531153135246" style="zoom:50%;" />





#### paint.py 画板

​		这个程序实现了一个简易的画板。用户可以：更改颜色 、绘制图形等。

````python
"""Paint, for drawing shapes.

Exercises

1. Add a color.
2. Complete circle.
3. Complete rectangle.
4. Complete triangle.
5. Add width parameter.
"""

import turtle

from utils import vector


def line(start, end):
    """Draw line from start to end."""
    turtle.up()
    turtle.goto(start.x, start.y)
    turtle.down()
    turtle.goto(end.x, end.y)


def square(start, end):
    """Draw square from start to end."""
    turtle.up()
    turtle.goto(start.x, start.y)
    turtle.down()
    turtle.begin_fill()

    for count in range(4):
        turtle.forward(end.x - start.x)
        turtle.left(90)

    turtle.end_fill()


def circle(start, end):
    """Draw circle from start to end."""
    pass  # TODO


def rectangle(start, end):
    """Draw rectangle from start to end."""
    pass  # TODO


def triangle(start, end):
    """Draw triangle from start to end."""
    pass  # TODO


def tap(x, y):
    """Store starting point or draw shape."""
    start = state['start']

    if start is None:
        state['start'] = vector(x, y)
    else:
        shape = state['shape']
        end = vector(x, y)
        shape(start, end)
        state['start'] = None


def store(key, value):
    """Store value in state at key."""
    state[key] = value


state = {'start': None, 'shape': line}
turtle.setup(420, 420, 370, 0)
turtle.onscreenclick(tap)
turtle.listen()
turtle.onkey(turtle.undo, 'u')
turtle.onkey(lambda: turtle.color('black'), 'K')
turtle.onkey(lambda: turtle.color('white'), 'W')
turtle.onkey(lambda: turtle.color('green'), 'G')
turtle.onkey(lambda: turtle.color('blue'), 'B')
turtle.onkey(lambda: turtle.color('red'), 'R')
turtle.onkey(lambda: store('shape', line), 'l')
turtle.onkey(lambda: store('shape', square), 's')
turtle.onkey(lambda: store('shape', circle), 'c')
turtle.onkey(lambda: store('shape', rectangle), 'r')
turtle.onkey(lambda: store('shape', triangle), 't')
turtle.done()
````



<img src="pics\paint.png" alt="image-20220531153613223" style="zoom:50%;" />



#### pong.py 二维弹球

​		双侧弹球小游戏。玩家需要操控两侧的挡板接住小球，不让其撞到墙上。一个考验反应力与协调性的小游戏。

```python
"""Pong, classic arcade game.

Exercises

1. Change the colors.
2. What is the frame rate? Make it faster or slower.
3. Change the speed of the ball.
4. Change the size of the paddles.
5. Change how the ball bounces off walls.
6. How would you add a computer player?
6. Add a second ball.
"""

from random import choice, random
import turtle
from utils import vector


def value():
    """Randomly generate value between (-5, -3) or (3, 5)."""
    return (3 + random() * 2) * choice([1, -1])


ball = vector(0, 0)
aim = vector(value(), value())
state = {1: 0, 2: 0}


def move(player, change):
    """Move player position by change."""
    state[player] += change


def rectangle(x, y, width, height):
    """Draw rectangle at (x, y) with given width and height."""
    turtle.up()
    turtle.goto(x, y)
    turtle.down()
    turtle.begin_fill()
    for count in range(2):
        turtle.forward(width)
        turtle.left(90)
        turtle.forward(height)
        turtle.left(90)
    turtle.end_fill()


def draw():
    """Draw game and move pong ball."""
    turtle.clear()
    rectangle(-200, state[1], 10, 50)
    rectangle(190, state[2], 10, 50)

    ball.move(aim)
    x = ball.x
    y = ball.y

    turtle.up()
    turtle.goto(x, y)
    turtle.dot(10)
    turtle.update()

    if y < -200 or y > 200:
        aim.y = -aim.y

    if x < -185:
        low = state[1]
        high = state[1] + 50

        if low <= y <= high:
            aim.x = -aim.x
        else:
            return

    if x > 185:
        low = state[2]
        high = state[2] + 50

        if low <= y <= high:
            aim.x = -aim.x
        else:
            return

    turtle.ontimer(draw, 50)


turtle.setup(420, 420, 370, 0)
turtle.hideturtle()
turtle.tracer(False)
turtle.listen()
turtle.onkey(lambda: move(1, 20), 'w')
turtle.onkey(lambda: move(1, -20), 's')
turtle.onkey(lambda: move(2, 20), 'i')
turtle.onkey(lambda: move(2, -20), 'k')
draw()
turtle.done()

```



<img src="pics\pang.png" alt="image-20220531160250951" style="zoom:50%;" />



#### simmonsays.py 顺序记忆

​		记忆力小游戏 again。玩家需要记住色块亮起的顺序，并按照相应的顺序点击色块。顺序序列的长度每次递增。

```python
"""Simon Says

Exercises

1. Speed up tile flash rate.
2. Add more tiles.
"""

from random import choice
from time import sleep
import turtle

from utils import floor, square, vector

pattern = []
guesses = []
tiles = {
    vector(0, 0): ('red', 'dark red'),
    vector(0, -200): ('blue', 'dark blue'),
    vector(-200, 0): ('green', 'dark green'),
    vector(-200, -200): ('yellow', 'khaki'),
}


def grid():
    """Draw grid of tiles."""
    square(0, 0, 200, 'dark red')
    square(0, -200, 200, 'dark blue')
    square(-200, 0, 200, 'dark green')
    square(-200, -200, 200, 'khaki')
    turtle.update()


def flash(tile):
    """Flash tile in grid."""
    glow, dark = tiles[tile]
    square(tile.x, tile.y, 200, glow)
    turtle.update()
    sleep(0.5)
    square(tile.x, tile.y, 200, dark)
    turtle.update()
    sleep(0.5)


def grow():
    """Grow pattern and flash tiles."""
    tile = choice(list(tiles))
    pattern.append(tile)

    for tile in pattern:
        flash(tile)

    print('Pattern length:', len(pattern))
    guesses.clear()


def tap(x, y):
    """Respond to screen tap."""
    turtle.onscreenclick(None)
    x = floor(x, 200)
    y = floor(y, 200)
    tile = vector(x, y)
    index = len(guesses)

    if tile != pattern[index]:
        exit()

    guesses.append(tile)
    flash(tile)

    if len(guesses) == len(pattern):
        grow()

    turtle.onscreenclick(tap)


def start(x, y):
    """Start game."""
    grow()
    turtle.onscreenclick(tap)


turtle.setup(420, 420, 370, 0)
turtle.hideturtle()
turtle.tracer(False)
grid()
turtle.onscreenclick(start)
turtle.done()
```



<img src="pics\simon.png" alt="image-20220531160921000" style="zoom:50%;" />





#### snake.py 贪吃蛇

​		经典游戏。

```python
"""Snake, classic arcade game.

Exercises

1. How do you make the snake faster or slower?
2. How can you make the snake go around the edges?
3. How would you move the food?
4. Change the snake to respond to mouse clicks.
"""

from random import randrange
import turtle

from utils import vector


food = vector(0, 0)
snake = [vector(10, 0)]
aim = vector(0, -10)


def change(x, y):
    """Change snake direction."""
    aim.x = x
    aim.y = y


def square(x, y, size, name):
    """
    Draw square at `(x, y)` with side length `size` and fill color `name`.

    The square is oriented so the bottom left corner is at (x, y).

    """
    import turtle

    turtle.up()
    turtle.goto(x, y)
    turtle.down()
    turtle.color(name)
    turtle.begin_fill()

    for count in range(4):
        turtle.forward(size)
        turtle.left(90)

    turtle.end_fill()


def inside(head):
    """Return True if head inside boundaries."""
    return -200 < head.x < 190 and -200 < head.y < 190


def move():
    """Move snake forward one segment."""
    head = snake[-1].copy()
    head.move(aim)

    if not inside(head) or head in snake:
        square(head.x, head.y, 9, 'red')
        turtle.update()
        return

    snake.append(head)

    if head == food:
        print('Snake:', len(snake))
        food.x = randrange(-15, 15) * 10
        food.y = randrange(-15, 15) * 10
    else:
        snake.pop(0)

    turtle.clear()

    for body in snake:
        square(body.x, body.y, 9, 'black')

    square(food.x, food.y, 9, 'green')
    turtle.update()
    turtle.ontimer(move, 100)


turtle.setup(420, 420, 370, 0)
turtle.hideturtle()
turtle.tracer(False)
turtle.listen()
turtle.onkey(lambda: change(10, 0), 'Right')
turtle.onkey(lambda: change(-10, 0), 'Left')
turtle.onkey(lambda: change(0, 10), 'Up')
turtle.onkey(lambda: change(0, -10), 'Down')
move()
turtle.done()
```



<img src="pics\snake.png" alt="image-20220531161338857" style="zoom: 50%;" />





#### tictactoe.py 井字棋

​		双人小游戏之井字棋。

```python
"""Tic Tac Toe

Exercises

1. Give the X and O a different color and width.
2. What happens when someone taps a taken spot?
3. How would you detect when someone has won?
4. How could you create a computer player?
"""

import turtle

from utils import line


def grid():
    """Draw tic-tac-toe grid."""
    line(-67, 200, -67, -200)
    line(67, 200, 67, -200)
    line(-200, -67, 200, -67)
    line(-200, 67, 200, 67)


def drawx(x, y):
    """Draw X player."""
    line(x, y, x + 133, y + 133)
    line(x, y + 133, x + 133, y)


def drawo(x, y):
    """Draw O player."""
    turtle.up()
    turtle.goto(x + 67, y + 5)
    turtle.down()
    turtle.circle(62)


def floor(value):
    """Round value down to grid with square size 133."""
    return ((value + 200) // 133) * 133 - 200


state = {'player': 0}
players = [drawx, drawo]


def tap(x, y):
    """Draw X or O in tapped square."""
    x = floor(x)
    y = floor(y)
    player = state['player']
    draw = players[player]
    draw(x, y)
    turtle.update()
    state['player'] = not player


turtle.setup(420, 420, 370, 0)
turtle.hideturtle()
turtle.tracer(False)
grid()
turtle.update()
turtle.onscreenclick(tap)
turtle.done()
```

<img src="pics\tictactoe.png" alt="image-20220531161657074" style="zoom:50%;" />





#### tiles.py 数字华容道

​		经典游戏。玩家需要将数字按照升序进行排列。

```python
"""Tiles, number swapping game.

Exercises

1. Track a score by the number of tile moves.
2. Permit diagonal squares as neighbors.
3. Respond to arrow keys instead of mouse clicks.
4. Make the grid bigger.
"""

import random
import turtle

from utils import floor, vector

tiles = {}
neighbors = [
    vector(100, 0),
    vector(-100, 0),
    vector(0, 100),
    vector(0, -100),
]


def load():
    """Load tiles and scramble."""
    count = 1

    for y in range(-200, 200, 100):
        for x in range(-200, 200, 100):
            mark = vector(x, y)
            tiles[mark] = count
            count += 1

    tiles[mark] = None

    for count in range(1000):
        neighbor = random.choice(neighbors)
        spot = mark + neighbor

        if spot in tiles:
            number = tiles[spot]
            tiles[spot] = None
            tiles[mark] = number
            mark = spot


def square(mark, number):
    """Draw white square with black outline and number."""
    turtle.up()
    turtle.goto(mark.x, mark.y)
    turtle.down()

    turtle.color('black', 'white')
    turtle.begin_fill()
    for count in range(4):
        turtle.forward(99)
        turtle.left(90)
    turtle. end_fill()

    if number is None:
        return
    elif number < 10:
        turtle.forward(20)

    turtle.write(number, font=('Arial', 60, 'normal'))


def tap(x, y):
    """Swap tile and empty square."""
    x = floor(x, 100)
    y = floor(y, 100)
    mark = vector(x, y)

    for neighbor in neighbors:
        spot = mark + neighbor

        if spot in tiles and tiles[spot] is None:
            number = tiles[mark]
            tiles[spot] = number
            square(spot, number)
            tiles[mark] = None
            square(mark, None)


def draw():
    """Draw all tiles."""
    for mark in tiles:
        square(mark, tiles[mark])
    turtle.update()


turtle.setup(420, 420, 370, 0)
turtle.hideturtle()
turtle.tracer(False)
load()
draw()
turtle.onscreenclick(tap)
turtle.done()
```



<img src="pics\tiles.png" alt="image-20220531162915907" style="zoom:50%;" />



#### tron.py 领土战争

​		双人小游戏。红蓝双方需要控制自己的像素点移动，占领尽可能多的区域。玩家不能进入不属于自己颜色的区域。游戏的核心是：活到最后！

```python
"""Tron, classic arcade game.

Exercises

1. Make the tron players faster/slower.
2. Stop a tron player from running into itself.
3. Allow the tron player to go around the edge of the screen.
4. How would you create a computer player?
"""

import turtle

from utils import square, vector

p1xy = vector(-100, 0)
p1aim = vector(4, 0)
p1body = set()

p2xy = vector(100, 0)
p2aim = vector(-4, 0)
p2body = set()


def inside(head):
    """Return True if head inside screen."""
    return -200 < head.x < 200 and -200 < head.y < 200


def draw():
    """Advance players and draw game."""
    p1xy.move(p1aim)
    p1head = p1xy.copy()

    p2xy.move(p2aim)
    p2head = p2xy.copy()

    if not inside(p1head) or p1head in p2body:
        print('Player blue wins!')
        return

    if not inside(p2head) or p2head in p1body:
        print('Player red wins!')
        return

    p1body.add(p1head)
    p2body.add(p2head)

    square(p1xy.x, p1xy.y, 3, 'red')
    square(p2xy.x, p2xy.y, 3, 'blue')
    turtle.update()
    turtle.ontimer(draw, 50)


turtle.setup(420, 420, 370, 0)
turtle.hideturtle()
turtle.tracer(False)
turtle.listen()
turtle.onkey(lambda: p1aim.rotate(90), 'a')
turtle.onkey(lambda: p1aim.rotate(-90), 'd')
turtle.onkey(lambda: p2aim.rotate(90), 'j')
turtle.onkey(lambda: p2aim.rotate(-90), 'l')
draw()
turtle.done()
```



<img src="pics\tron.png" alt="image-20220531163244268" style="zoom:50%;" />



