## Level 5 Free-Python-games 内容完善

> PB20111699
>
> 吴骏东

### 1.内容简介

​		Free-python-games 是一个汇聚了多款小游戏的开源项目。本实验在针对此开源项目进行了复现的基础上，对其内部大部分都游戏进行了改动，实现了功能的完善与内部逻辑的升级。



### 2.完善说明

​		复现的过程中，针对部分包导入进行了修改，保证了程序的可执行性。对于部分程序，本实验根据我对其的理解与程序本身提供的提示进行了一定的更改，同时**增加**了一部分全新的小游戏以丰富内容。

​		**升级后的 Free-python-games 有了更为完善的游戏体验、更为丰富的游戏内容与更加好的扩展性，同时也提升了用户的使用便捷度。程序也为后续的游戏添加预留了接口**。

​		使用时，直接运行 /source 中的 start.py 即可。也可以单独运行其他的小游戏文件。



#### start.py：初始界面与游戏选择

​		本实验增加了一个命令行界面用于玩家交互与游戏选择。尽管相对见喽，但其内部功能已经较为完善。包括：

- 游戏列表查看与选择
- 游戏介绍
- 随机选择
- 退出

运行 start.py 后的界面效果如下：

```
Welcome to Free-Python-Games.
This project is adapted from github project [free-pythpn-game].
Website: http://www.grantjenks.com/docs/freegames/
This project is ONLY for the course <Interdisciplinary Python Programming and Interdisciplinary Practice>
Now, enjoy the game!





Play something, have a rest~
[List]           [Info]          [Random]         [Exit]
[Input]:
```

输入 list，则会打印当前所有小游戏列表：

```
     ================================   GAME LIST   ======================================
     1.[Ant]          2.[Bagles]          3.[Boom]          4.[Bounce]          5.[Cannon]
     6.[Connect]          7.[Crypto]          8.[Fidget]          9.[Flappy]          10.[Guess]
     11.[Life]          12.[Madlibs]          13.[Maze]          14.[Memory]          15.[Minesweeper]
     16.[Pacman]          17.[Paint]          18.[Pong]          19.[Rps_game]          20.[Simonsays]
     21.[Snake]          22.[Tictactoe]          23.[Tiles]          24.[Tron]
     =====================================================================================


Please input the number to play the game.
Input 0 for quit.
[input]:
```

输入游戏对应的编号即可开始游玩；输入 0 返回上一级菜单。

输入 info，则会打印所有的小游戏介绍：

```
The game introduction is as below.
========================================================
[Cannon]
    Projectile motion. Click the screen to fire your cannnonball. The
cannonball pops blue balloons in its path. Pop all the balloons before they can
cross the screen.

[Connect]
    Connect 4 game. Click a row to drop a disc. The first player to
connect four discs vertically, horizontally, or diagonally wins!

[Fidget]
     Fidget spinner inspired animation. Click the screen to accelerate
the fidget spinner.

[Flappy]
    Flappy-bird inspired game. Click the screen to flap your
wings. Watch out for black ravens as you fly across the screen.

[Life]
     Conway's Game of Life. The classic, zero-player, cellular automation
created in 1970 by John Conway.

[Maze]
    Move from one side to another. Inspired by `A Universe in One Line
of Code with 10 PRINT`_. Tap the screen to trace a path from one side to
another.

[Memory]
    Puzzle game of number pairs. Click a tile to reveal a
number. Match two numbers and the tiles will disappear to reveal an image.

[Pacman]
    Classic arcade game. Use the arrow keys to navigate and eat all
the white food. Watch out for red ghosts that roam the maze.

[Paint]
    Draw lines and shapes on the screen. Click to mark the start of a
shape and click again to mark its end. Different shapes and colors can be
selected using the keyboard.

[Pong]
    Classic arcade game. Use the keyboard to move your paddle up and
down. The first player to miss the ball loses.

[Simon Says]
    Classic memory puzzle game. Click the screen to start. Watch
the pattern and then click the tiles in the same order. Each time you get the
sequence right the pattern gets one step longer.

[Snake]
    Classic arcade game. Use the arrow keys to navigate and eat the
green food. Each time the food is consumed, the snake grows one segment
longer. Avoid eating yourself or going out of bounds!

[Tic Tac Toe]
    Classic game. Click the screen to place an X or O. Connect
three in a row and you win!

[Tiles]
    Puzzle game of sliding numbers into place. Click a tile adjacent to
the empty square to swap positions. Can you make the tiles count one to fifteen
from left to right and bottom to top?

[Tron]
    Classic arcade game. Use the keyboard to change the direction of
your Tron player. Avoid touching the line drawn by your opponent.
```

输入 random，则会随机选择并启动一款小游戏：

```
Play something, have a rest~
[List]           [Info]          [Random]         [Exit]
[Input]:random
 

This game is: Maze
The game will start in 3...
The game will start in 2...
The game will start in 1...
```

输入 exit，则会退出当前程序。



#### ant.py：蚂蚁行为仿真[升级]

​		这是一个可以模拟蚂蚁运动行为的程序。运行程序后，在打开的窗口界面中会生成一个黑色像素点（蚂蚁）。每一时刻它都会随机移动一段距离，并旋转一定角度。

​		在本实验中的改进如下：

  1. **增加了边界显示（蓝色矩形）；**

  2. **增加了行迹显示（红色线条、黑色点）；**

  3. **现在蚂蚁遇到边界时会进行转向（掉头）。**

     

```Python
"""Ant, simple animation demo.

Exercises

1. Wrap ant around screen boundaries.
2. Make the ant leave a trail.
3. Change the ant color based on position.
   Hint: colormode(255); color(0, 100, 200)
"""

import random
import turtle
from utils import vector

ant = vector(0, 0)
aim = vector(2, 0)


def wrap(value):
    """Wrap value around -200 and 200."""
    if value >= 300:
        value = 300
    elif value <= -300:
        value = -300
    return value  # TODO


def draw():
    """Move ant and draw screen."""
    ant.move(aim)
    ant.x = wrap(ant.x)
    ant.y = wrap(ant.y)

# aturtle.pendown()   移动时绘制图形
# turtle.goto(x,y)    将画笔移动到坐标为x,y的位置
    aim.move(random.random() * 0.5 - 0.25)
    if ant.x >= 300 or ant.x <= -300 or ant.y >= 300 or ant.y <= -300:
        aim.rotate(90)
    else:
        aim.rotate(random.random() * 40 - 20)

'''
	这里的边界转向实现逻辑较为简单：如果蚂蚁运动到了边界处，则让其左转九十度。当蚂蚁斜向来到边界时，这样的处理看起来相对比较自然。对于垂直方向运动到边界时的情况，这样的设计会看起来有点奇怪，不过尚在可以接受的范围之内。
'''
    

    # turtle.clear()
    turtle.pendown()
    turtle.color("red")
    turtle.goto(ant.x, ant.y)
    turtle.color("black")
    turtle.dot(3)

    turtle.ontimer(draw, 80)


# turtle.setup(420, 420, 370, 0)
turtle.setup(800, 800, 370, 0)
turtle.hideturtle()
turtle.tracer(False)
turtle.title("Ant Simulater")
turtle.up()

turtle.penup()
turtle.color("blue")
turtle.goto(300, -300)
turtle.left(90)
turtle.pendown()
turtle.forward(600)
turtle.left(90)
turtle.forward(600)
turtle.left(90)
turtle.forward(600)
turtle.left(90)
turtle.forward(600)
turtle.penup()
turtle.home()

draw()
turtle.done()
```

​		程序演示效果如下（挂机约 1 分钟的效果）：

<img src="pics\ants.png" alt="image-20220531225913876" style="zoom:50%;" />





#### bagels.py 经典数字推理游戏

​		数字推理游戏的基本思路是：对于未知的三位数，玩家可以通过逐次尝试法去获取其可能的信息。每一次得到的信息包括：某一个数字正确、某一个数字正确且位置正确、所有数字均错误。根据有限的信息，玩家需要更改自己的猜测，并在规定的次数内得到最终结果。

​		相比编程而言，可能玩游戏本身更难一点。

```python
"""Bagels, a number puzzle game.

Exercises:

1. Can you guess the number?
2. How much harder is 6 digits? Do you need more guesses?
3. What's the maximum number of digits we could support?

Adapted from code in https://inventwithpython.com/chapter11.html
"""

from random import sample, shuffle

digits = 3
guesses = 10

print('I am thinking of a', digits, 'digit number.')
print('Try to guess what it is.')
print('Here are some clues:')
print('When I say:    That means:')
print('  pico         One digit is correct but in the wrong position.')
print('  fermi        One digit is correct and in the right position.')
print('  bagels       No digit is correct.')
print('There are no repeated digits in the number.')

# Create a random number.

letters = sample('0123456789', digits)

if letters[0] == '0':
    letters.reverse()

number = ''.join(letters)

print('I have thought up a number.')
print('You have', guesses, 'guesses to get it.')

counter = 1

while True:
    print('Guess #', counter)
    guess = input()

    if len(guess) != digits:
        print('Wrong number of digits. Try again!')
        continue

    # Create the clues.

    clues = []

    for index in range(digits):
        if guess[index] == number[index]:
            clues.append('fermi')
        elif guess[index] in number:
            clues.append('pico')

    shuffle(clues)

    if len(clues) == 0:
        print('bagels')
    else:
        print(' '.join(clues))

    counter += 1

    if guess == number:
        print('You got it!')
        break

    if counter > guesses:
        print('You ran out of guesses. The answer was', number)
        break

```

​		某一次的游戏过程如下：

```python
I am thinking of a 3 digit number.
Try to guess what it is.
Here are some clues:
When I say:    That means:
  pico         One digit is correct but in the wrong position.
  fermi        One digit is correct and in the right position.
  bagels       No digit is correct.
There are no repeated digits in the number.
I have thought up a number.
You have 10 guesses to get it.
Guess # 1
123
pico
Guess # 2
234
fermi fermi
Guess # 3
534
fermi fermi
Guess # 4
634
fermi fermi
Guess # 5
734
fermi fermi fermi
You got it!
```





#### boom.py 拆弹专家[新增]

​		改编自最经典的猜数字游戏，只不过这一次变成了尽可能不要猜中数字。每一次猜测都会缩小可能的范围，所以......小心行事！游戏内包含了范围检测与其他容错性设计。

```python
'''
The number guess game, but for 2 players!
Players will guess the number in turn
Anyone guesses the number first will LOSE
'''

import random as rd
import time
start = 1
end = 100
player = 1
playernum = int(input("Please input the number of players (MAX 4)\n[input]:"))
if playernum < 0:
    playernum = 1
elif playernum > 4:
    playernum = 4

value = rd.randint(start, end)

while True:
    print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n=====================================================")
    print("This is player {}'s round.".format(player))
    print("Choose a number between {} and {}.".format(start, end))
    while True:
        guess = int(input("[input]:"))
        if guess >= start and guess <= end:
            break
        print("Out of range. Please choose another number.")
    time.sleep(1)

    if guess == value:
        print("Ssssssssssss....")
        time.sleep(1)
        print("Boom!")
        time.sleep(1)
        print("Player {} was blown up, game over.".format(player))
        exit()
    elif guess < value:
        print("Not this one. It's bigger.")
        start = guess + 1
    else:
        print("Not this one. It's smaller.")
        end = guess - 1
    time.sleep(2)

    # Change the player
    if player >= playernum:
        player = 1
    else:
        player += 1
```

一次游戏的过程如下：

```
Please input the number of players (MAX 4)
[input]:3

=====================================================
This is player 1's round.
Choose a number between 1 and 100.
[input]:50
Not this one. It's bigger.

=====================================================
This is player 2's round.
Choose a number between 51 and 100.
[input]:75
Not this one. It's bigger.

=====================================================
This is player 3's round.
Choose a number between 76 and 100.
[input]:88
Not this one. It's smaller.

=====================================================
This is player 1's round.
Choose a number between 76 and 87.
[input]:80
Not this one. It's smaller.

=====================================================
This is player 2's round.
Choose a number between 76 and 79.
[input]:78
Ssssssssssss....
Boom!
Player 2 was blown up, game over.
```





#### bounce.py 弹球模拟器

​		一个物理模拟器。打开界面后，一个黑色的小球会在场地中一直运动。它会以窗口边界为墙体进行弹性碰撞，从而实现在窗口中的往复运动。不过目前没有玩家操控的内容。

```python
"""Bounce, a simple animation demo.

Exercises

1. Make the ball speed up and down.
2. Change how the ball bounces when it hits a wall.
3. Make the ball leave a trail.
4. Change the ball color based on position.
   Hint: colormode(255); color(0, 100, 200)
"""

import random 
import turtle 
from utils import vector


def value():
    """Randomly generate value between (-5, -3) or (3, 5)."""
    return (3 + random.random() * 2) * random.choice([1, -1])


ball = vector(0, 0)
aim = vector(value(), value())


def draw():
    """Move ball and draw game."""
    ball.move(aim)

    x = ball.x
    y = ball.y

    if x < -200 or x > 200:
        aim.x = -aim.x

    if y < -200 or y > 200:
        aim.y = -aim.y

    turtle.clear()
    turtle.goto(x, y)
    turtle.dot(10)

    turtle.ontimer(draw, 50)


turtle.setup(420, 420, 370, 0)
turtle.hideturtle()
turtle.tracer(False)
turtle.up()
draw()
turtle.done()
```

​		一个平平无奇的界面。

<img src="pics\bounce.png" alt="image-20220531142649682" style="zoom:67%;" />



#### cannon.py 加农炮之战

​		在这个小游戏中，用户需要通过鼠标操控屏幕左下角的加农炮发射炮弹（红色像素点），同时屏幕右侧会随机生成大量蓝色目标缓缓向左移动。游戏的核心便是尽可能击中这些目标。

```python
"""Cannon, hitting targets with projectiles.

Exercises

1. Keep score by counting target hits.
2. Vary the effect of gravity.
3. Apply gravity to the targets.
4. Change the speed of the ball.
"""

from random import randrange
import turtle
from utils import vector

ball = vector(-200, -200)
speed = vector(0, 0)
targets = []


def tap(x, y):
    """Respond to screen tap."""
    if not inside(ball):
        ball.x = -199
        ball.y = -199
        speed.x = (x + 200) / 25
        speed.y = (y + 200) / 25


def inside(xy):
    """Return True if xy within screen."""
    return -200 < xy.x < 200 and -200 < xy.y < 200


def draw():
    """Draw ball and targets."""
    turtle.clear()

    for target in targets:
        turtle.goto(target.x, target.y)
        turtle.dot(20, 'blue')

    if inside(ball):
        turtle.goto(ball.x, ball.y)
        turtle.dot(6, 'red')

    turtle.update()


def move():
    """Move ball and targets."""
    if randrange(40) == 0:
        y = randrange(-150, 150)	# 随机生成蓝色目标的纵坐标
        target = vector(200, y)
        targets.append(target)

    for target in targets:
        target.x -= 0.5

    if inside(ball):
        speed.y -= 0.35
        ball.move(speed)

    dupe = targets.copy()
    targets.clear()

    for target in dupe:
        if abs(target - ball) > 13:
            targets.append(target)

    draw()

    for target in targets:
        if not inside(target):
            return

    turtle.ontimer(move, 30)


turtle.setup(420, 420, 370, 0)
turtle.hideturtle()
turtle.up()
turtle.tracer(False)
turtle.onscreenclick(tap)
move()
turtle.done()
```





<img src="pics\cannon.png" alt="image-20220531142959227" style="zoom:67%;" />



#### connetc.py 四子棋[升级]

​		这是一个双人小游戏。和五子棋的规则类似，四子棋要求任意一名玩家的四个棋子按横竖斜的任何方式排成一排即可取得胜利。但不同的是，本游戏的棋盘处于竖直平面内。玩家只能在现有棋子的上方或最下面一排落子。这样的设定在一定程度上增强了游戏的策略性。

​		本实验进行的改动如下：

1. **增加了对于边界范围的限制。现在玩家无法将棋子放在区域外的位置上。**
2. **增加了胜负判定，任何横竖斜先四子连线的玩家获得胜利**
3. **游戏内部逻辑的相关改动**

```python
"""Connect Four

Exercises

1. Change the colors.
2. Draw squares instead of circles for open spaces.
3. Add logic to detect a full row.
4. Create a random computer player.
5. How would you detect a winner?
"""

"""
Improve:

1. Add the class for players
2. Detect a winner
3. Add logic to detect a full row.
"""

import turtle
import time
from utils import line



class Player(object):
    def __init__(self, color):
        self.color = color

    def change_color(self, color_new):
        self.color = color_new


game_state = [[[0 for i in range (9)] for _ in range(8)] for _ in range(8)]

# This array stores the number of points in different ways.
# 0 --- player number 0 or 1
# 1 --- up
# 2 --- up and left
#       ...
# 8 --- up and right

offset = [[0] * 2 for _ in range (8)]
offset[0] = [0, 1]
offset[1] = [-1, 1]
offset[2] = [-1, 0]
offset[3] = [-1, -1]
offset[4] = [0, -1]
offset[5] = [1, -1]
offset[6] = [1, 0]
offset[7] = [1, 1]

current_id = 1

def winner_detect(row, col, player_id):
    global game_state, offset, current_id


    game_state[row][col][0] = player_id

    for i in range(0, 8):
        check_row = row + offset[i][0]
        check_col = col + offset[i][1]
        # Detect the edge
        if check_row < 0 or check_row > 7 or check_col < 0 or check_col > 7:
            continue

        if game_state[row][col][0] == game_state[check_row][check_col][0]:
            game_state[row][col][i + 1] = game_state[check_row][check_col][i + 1] + 1
            game_state[check_row][check_col][(i + 4) % 8 + 1] = game_state[row][col][(i + 4) % 8 + 1] + 1
            if game_state[row][col][i + 1] >= 3:
                print("Braveo!")
                time.sleep(0.5)
                print("Player " + str(player_id), end= " ")
                print("Win!") 
                time.sleep(2)
                print("The game will end in 3...")
                time.sleep(1)
                print("The game will end in 2...")
                time.sleep(1)
                print("The game will end in 1...")
                time.sleep(1)
                exit()


turns = {'red': 'yellow', 'yellow': 'red'}
state = {'player': 'yellow', 'rows': [0] * 8}


def grid():
    """Draw Connect Four grid."""
    turtle.bgcolor('light blue')

    for x in range(-200, 250, 50):
        line(x, -200, x, 200)
        line(-200, x, 200, x)

    for x in range(-175, 200, 50):
        for y in range(-175, 200, 50):
            turtle.up()
            turtle.goto(x, y)
            turtle.dot(40, 'white')

    turtle.update()


def tap(x, y):
    """Draw red or yellow circle in tapped row."""
    global current_id

    player = state['player']
    rows = state['rows']

    col = int((x + 200) // 50)
    if col < 0 or col > 7:
        print("Out of the ground!")
        return
    count = rows[col]

    x = ((x + 200) // 50) * 50 - 200 + 25
    y = count * 50 - 200 + 25

    if y > 200:
        print("This colmun is full!")
        print("Please try another place")
        return

    turtle.up()
    turtle.goto(x, y)
    turtle.dot(40, player)
    turtle.update()

    rows[col] = count + 1
    state['player'] = turns[player]

    md_row = int((x + 175) // 50)
    md_col = 7 - int((y + 175) // 50)

    # print(md_row)
    # print(md_col)

    # winner_detect(md_row, md_col, current_id)

    # print(current_id)
    player_id = current_id
    winner_detect(md_row, md_col, player_id)
    if current_id == 1:
        current_id = 2
    else:
        current_id = 1

# Begins from now
turtle.setup(500, 500, 370, 0)
turtle.hideturtle()
turtle.tracer(False)


# Game start
# Player 0 starts first
grid()
turtle.onscreenclick(tap)
turtle.done()

```

<img src="D:\0-Programmingformelon\python\level5\pics\connect.png" alt="image-20220626100919015" style="zoom:50%;" />





#### crypto.py 加密解密程序[升级]

​		这个程序为用户提供了基于凯撒密码的加密解密工具。凯撒密码的核心是对所有的字母进行移位对应，因此至多有 26 种加密方式。根据密钥（移位量）的不同，加密解密的结果也不同。

​		本实验为其增加了**暴力解码**过程：密钥一共有 25 种，对于输入的密文，针对每一种密钥分别进行解码，将结果全部输出即可。

```python
"""Crypto: tool for encrypting and decrypting messages.

Exercises

1. Review 'ord' and 'chr' functions and letter-to-number mapping.
2. Explain what happens if you use key 26.
3. Find a way to decode a message without a key.
4. Encrypt numbers.
5. Make the encryption harder to decode.

Adapted from code in https://inventwithpython.com/chapter14.html
"""


def encrypt(message, key):
    """Encrypt message with key."""
    result = ''

    # Iterate letters in message and encrypt each individually.

    for letter in message:
        if letter.isalpha():

            # Letters are numbered like so:
            # A, B, C - Z is 65, 66, 67 - 90
            # a, b, c - z is 97, 98, 99 - 122

            num = ord(letter)

            if letter.isupper():
                base = ord('A')
            else:
                assert letter.islower()
                base = ord('a')

            # The encryption equation:

            num = (num - base + key) % 26 + base

            result += chr(num)

        elif letter.isdigit():

            # Encrypt digits.
            result += str((int(letter) + key) % 10)

        else:
            result += letter

    return result


def decrypt(message, key):
    """Decrypt message with key."""
    return encrypt(message, -key)


def decode(message):
    """Decode message without key."""
    for key in range(1, 26):
        print("Key ", end = "")
        print(key, end = "")
        print(": ", end = "")
        print(decrypt(message, key))
    

def get_key():
    """Get key from user."""
    try:
        text = input('Enter a key (1 - 25): ')
        key = int(text)
        return key
    except Exception:
        print('Invalid key. Using key: 0.')
        return 0


print('Do you wish to encrypt, decrypt, or decode a message?')
choice = input()

if choice == 'encrypt':
    phrase = input('Message: ')
    code = get_key()
    print('Encrypted message:', encrypt(phrase, code))
elif choice == 'decrypt':
    phrase = input('Message: ')
    code = get_key()
    print('Decrypted message:', decrypt(phrase, code))
elif choice == 'decode':
    phrase = input('Message: ')
    print('Decoding message:')
    decode(phrase)
else:
    print('Error: Unrecognized Command')

```

​		一个简单的测试：

```python
Do you wish to encrypt, decrypt, or decode a message?
encrypt
Message: hello world!
Enter a key (1 - 25): 5
Encrypted message: mjqqt btwqi!


Do you wish to encrypt, decrypt, or decode a message?
decrypt
Message: mjqqt btwqi!
Enter a key (1 - 25): 5
Decrypted message: hello world!
    
Do you wish to encrypt, decrypt, or decode a message?
decode
Message: tqxxa iadxp
Decoding message:
Key 1: spwwz hzcwo
Key 2: rovvy gybvn
Key 3: qnuux fxaum
Key 4: pmttw ewztl
Key 5: olssv dvysk
Key 6: nkrru cuxrj
Key 7: mjqqt btwqi
Key 8: lipps asvph
Key 9: khoor zruog
Key 10: jgnnq yqtnf
Key 11: ifmmp xpsme
Key 12: hello world  (The answer)
Key 13: gdkkn vnqkc
Key 14: fcjjm umpjb
Key 15: ebiil tloia
Key 16: dahhk sknhz
Key 17: czggj rjmgy
Key 18: byffi qilfx
Key 19: axeeh phkew
Key 20: zwddg ogjdv
Key 21: yvccf nficu
Key 22: xubbe mehbt
Key 23: wtaad ldgas
Key 24: vszzc kcfzr
Key 25: uryyb jbeyq
```





#### fidget.py 指尖陀螺模拟器

​		这个小游戏模拟了一个简单的指尖陀螺。用户只需要按下空格键即可为其加速。连续按动空格键，指尖陀螺将加速旋转；而一段时间不按动空格键，指尖陀螺会缓缓停止。

```python
"""Fidget, inspired by fidget spinners.

Exercises

1. Change the spinner pattern.
2. Respond to mouse clicks.
3. Change its acceleration.
4. Make it go forwards and backwards.
"""

import turtle
state = {'turn': 0}


def spinner():
    """Draw fidget spinner."""
    turtle.clear()
    angle = state['turn'] / 10
    turtle.right(angle)
    turtle.forward(100)
    turtle.dot(120, 'red')
    turtle.back(100)
    turtle.right(120)
    turtle.forward(100)
    turtle.dot(120, 'green')
    turtle.back(100)
    turtle.right(120)
    turtle.forward(100)
    turtle.dot(120, 'blue')
    turtle.back(100)
    turtle.right(120)
    turtle.update()


def animate():
    """Animate fidget spinner."""
    if state['turn'] > 0:
        state['turn'] -= 1

    spinner()
    turtle.ontimer(animate, 20)


def flick():
    """Flick fidget spinner."""
    state['turn'] += 10


turtle.setup(420, 420, 370, 0)
turtle.hideturtle()
turtle.tracer(False)
turtle.width(20)
turtle.onkey(flick, 'space')
turtle.listen()
animate()
turtle.done()
```



<img src="pics\fidget.png" alt="image-20220531145131013" style="zoom: 50%;" />





#### flappy.py 飞翔鸟

​		经典的 Flappy Bird 游戏改编。现在玩家操控的不是小鸟而是小球。每一次单击会让小球向上移动一段距离，随后自由落下。玩家需要合理控制单击的时机以躲避障碍物。

```python
"""Flappy, game inspired by Flappy Bird.

Exercises

1. Keep score.
2. Vary the speed.
3. Vary the size of the balls.
4. Allow the bird to move forward and back.
"""

import random
import turtle
from utils import vector

bird = vector(0, 0)
balls = []


def tap(x, y):
    """Move bird up in response to screen tap."""
    up = vector(0, 50)
    bird.move(up)


def inside(point):
    """Return True if point on screen."""
    return -200 < point.x < 200 and -200 < point.y < 200


def draw(alive):
    """Draw screen objects."""
    turtle.clear()

    turtle.goto(bird.x, bird.y)

    if alive:
        turtle.dot(10, 'green')
    else:
        turtle.dot(10, 'red')

    for ball in balls:
        turtle.goto(ball.x, ball.y)
        turtle.dot(20, 'black')

    turtle.update()


def move():
    """Update object positions."""
    bird.y -= 5

    for ball in balls:
        ball.x -= 3

    if random.randrange(10) == 0:
        y = random.randrange(-199, 199)
        ball = vector(199, y)
        balls.append(ball)

    while len(balls) > 0 and not inside(balls[0]):
        balls.pop(0)

    if not inside(bird):
        draw(False)
        return

    for ball in balls:
        if abs(ball - bird) < 15:
            draw(False)
            return

    draw(True)
    turtle.ontimer(move, 50)


turtle.setup(420, 420, 370, 0)
turtle.hideturtle()
turtle.up()
turtle.tracer(False)
turtle.onscreenclick(tap)
move()
turtle.done()
```



<img src="pics\flappy.png" alt="flappy" style="zoom:50%;" />





#### guess.py 猜数字[升级]

​		根据大小猜数字。二分查找的启蒙制作（

本次实验中的改动：

​		**增加了欺骗模式！但给出的大小判断只有一定的的准确率（笑）**

```python
"""Guess a number within a range.

Exercises

1. Change the range to be from 0 to 1,000,000.
2. Can you still guess the number?
3. Print the number of guesses made.
4. Limit the number of guesses to the minimum required.
"""

from random import randint

start = 1
end = 100
value = randint(start, end)

# print(value)
print("I'm thinking of a number between", start, 'and', end)
T = int(input("Please input the honesty percent (From 0 to 100):\n[input]:"))
if T < 0:
    T = 0
elif T > 100:
    T = 100

guess = None

while guess != value:
    text = input('Guess the number: ')
    guess = int(text)

    flag = randint(1,100)
    if flag < T:
        if guess < value:
            print('Higher.')
        elif guess > value:
            print('Lower.')
    else:
        if guess < value:
            print('Lower.')
        elif guess > value:
            print('Higher.')

print('Congratulations! You guessed the right answer:', value)
```

​		一次尝试如下：

```
I'm thinking of a number between 1 and 100
Please input the honesty percent (From 0 to 100):
[input]:90
Guess the number: 50
Higher.
Guess the number: 75
Lower.									<- This is wrong
Guess the number: 60
Higher.
Guess the number: 70
Higher.
Guess the number: 72
Higher.
Guess the number: 73
Lower.									<- This is wrong
Guess the number: 72
Higher.
Guess the number: 74
Higher.
Guess the number: 80
Higher.
Guess the number: 90
Higher.									<- This is wrong
Guess the number: 95
Lower.
Guess the number: 92
Lower.
Guess the number: 91
Lower.
Guess the number: 90
Lower.
Guess the number: 88
Lower.
Guess the number: 80
Higher.
Guess the number: 85
Higher.
Guess the number: 87
Lower.
Guess the number: 86
Congratulations! You guessed the right answer: 86
```





#### life.py 生命游戏[升级]

​		生命游戏是英国数学家 John Conway 在 1970 年发明的细胞自动机。在一个二维点状平面上， 每一个点遵循如下规则：

1. 少于2个邻居的点，在下一回合死去。模拟生命较少的情况。
2. 在周围邻居数量是2和3时，下一回合保持不变
3. 在周围邻居数量大于3时，下一回合死去，模拟生命拥挤的情况。
4. 当一个空白的点，周围的邻居数量是3个是， 下一回合将会产生一个新的点。模拟繁殖。

尽管底层规则十分简单，但生命游戏的演化结果却包罗万象。事实上，我们可以用生命游戏来搭建一台计算机，从而模拟一切行为。

本实验进行的改动如下：

1. **调整了游戏演化的速率；**
2. **增加了一部分初始模型选择。**

```python
"""Game of Life simulation.

Conway's game of life is a classic cellular automation created in 1970 by John
Conway. https://en.wikipedia.org/wiki/Conway%27s_Game_of_Life

A special website simulator: https://funnyjs.com/jspages/game-of-life.html

Exercises

1. Can you identify any Still Lifes, Oscillators, or Spaceships?
2. How can you make the simulation faster? Or bigger?
3. How would you modify the initial state?
4. Try changing the rules of life :)
"""

from random import choice
import turtle
from utils import square

cells = {}


def initialize(mode = "random"):
    """initialize the cells according to the modes."""
    
    for x in range(-200, 200, 10):
        for y in range(-200, 200, 10):
            cells[x, y] = False

    if mode == "random" or mode == "none":
        for x in range(-50, 50, 10):
            for y in range(-50, 50, 10):
                cells[x, y] = choice([True, False])
    
    elif mode == "comb":
        cells[0, 0] = True
        cells[10, 0] = True
        cells[20, 10] = True
        cells[10, 20] = True
        cells[0, 20] = True
        cells[-10, 10] = True

    elif mode == "boat":
        cells[0, -10] = True
        cells[10, -10] = True
        cells[-10, 0] = True
        cells[10, 0] = True
        cells[-10, 10] = True
        cells[0, 10] = True

    elif mode == "star":
        cells[-40, -60] = True
        cells[-30, -60] = True
        cells[-20, -60] = True
        cells[40, -60] = True
        cells[30, -60] = True
        cells[20, -60] = True

        cells[-60, -40] = True
        cells[-10, -40] = True
        cells[60, -40] = True
        cells[10, -40] = True

        cells[-60, -30] = True
        cells[-10, -30] = True
        cells[60, -30] = True
        cells[10, -30] = True

        cells[-60, -20] = True
        cells[-10, -20] = True
        cells[60, -20] = True
        cells[10, -20] = True

        cells[-40, -10] = True
        cells[-30, -10] = True
        cells[-20, -10] = True
        cells[40, -10] = True
        cells[30, -10] = True
        cells[20, -10] = True

        cells[-40, 60] = True
        cells[-30, 60] = True
        cells[-20, 60] = True
        cells[40, 60] = True
        cells[30, 60] = True
        cells[20, 60] = True

        cells[-60, 40] = True
        cells[-10, 40] = True
        cells[60, 40] = True
        cells[10, 40] = True

        cells[-60, 30] = True
        cells[-10, 30] = True
        cells[60, 30] = True
        cells[10, 30] = True

        cells[-60, 20] = True
        cells[-10, 20] = True
        cells[60, 20] = True
        cells[10, 20] = True

        cells[-40, 10] = True
        cells[-30, 10] = True
        cells[-20, 10] = True
        cells[40, 10] = True
        cells[30, 10] = True
        cells[20, 10] = True

    elif mode == "spaceship":
        cells[-150, -20] = True
        cells[-140, -20] = True
        cells[-130, -20] = True
        cells[-120, -20] = True

        cells[-160, -10] = True
        cells[-120, -10] = True

        cells[-120, 0] = True
        cells[-160, 10] = True
        cells[-130, 10] = True

    else:
        print("Mode error!")
        cells[10, 10] = True
        cells[0, 0] = True
        cells[10, 0] = True
        cells[0, 10] = True

def step():
    """Compute one step in the Game of Life."""
    neighbors = {}

    for x in range(-190, 190, 10):
        for y in range(-190, 190, 10):
            count = -cells[x, y]
            for h in [-10, 0, 10]:
                for v in [-10, 0, 10]:
                    count += cells[x + h, y + v]
            neighbors[x, y] = count

    for cell, count in neighbors.items():
        if cells[cell]:
            if count < 2 or count > 3:
                cells[cell] = False
        elif count == 3:
            cells[cell] = True


def draw():
    """Draw all the squares."""
    step()
    turtle.clear()
    for (x, y), alive in cells.items():
        color = 'green' if alive else 'black'
        square(x, y, 10, color)
    turtle.update()
    
    draw()
    turtle.ontimer(draw, 100)


print("Pleast input the initial mode:\n    <none>/<random>: Randomly initialize.\n    <comb>: A honeycomb shape (static)\n    <boat>: A small boat (static)")
print("    <star>: A cycle change star. (dynamic)")
print("    <spaceship>: A spaceship which can move. (dynamic)")
mode = input("\n[input]:")
if mode == "":
    mode = "random"

turtle.setup(420, 420, 370, 0)
turtle.hideturtle()
turtle.tracer(False)
initialize(mode)
draw()
turtle.done()
```

运行程序后，会有如下的提示界面：

```
Pleast input the initial mode:
    <none>/<random>: Randomly initialize.
    <comb>: A honeycomb shape (static)
    <boat>: A small boat (static)
    <star>: A cycle change star. (dynamic)
    <spaceship>: A spaceship which can move. (dynamic)

[input]:
```

用户可以在两种静态图案、两种动态图案以及随机图案五种模式中进行初始化选择。例如，`star` 图案的效果为：

<img src="pics\life_star.png" alt="image-20220627133742286" style="zoom:50%;" />



#### madlib.py 故事制造机

​		这是一个荒诞故事生成器。程序根据用户输入的单词生成一个无厘头的句子。或许多人游戏时这个更加有趣。

```python
"""Mad Libs: Funny Story Creation Game

Exercises:

1. How to replace the story?
2. How load the story and from a file?
3. How to add additional parts of speech?
"""

# The quick brown fox jumps over the lazy dog.
template = 'The |1| |2| |3| |4| over the |5| |6|.'
parts = {
    '1': 'adjective',
    '2': 'adjective',
    '3': 'noun',
    '4': 'verb',
    '5': 'adjective',
    '6': 'noun',
}

chunks = []

for chunk in template.split('|'):
    if chunk in parts:
        description = parts[chunk]
        prompt = 'Enter [{}]: '.format(description)
        word = input(prompt)
        chunks.append(word)
    else:
        chunks.append(chunk)

print('=' * 80)
story = ''.join(chunks)
print(story)

```

​		一次测试如下：

```
Enter [adjective]: happy
Enter [adjective]: fast
Enter [noun]: apple
Enter [verb]: throw
Enter [adjective]: funny
Enter [noun]: tree
================================================================================
The happy fast apple throw over the funny tree.
```



#### maze.py 迷宫游戏

​		这是一个简单的迷宫小游戏。玩家可以通过单击绘制路径。游戏目标是穿过迷宫，不过目前并没有一种检测方式......

```python
"""Maze, move from one side to another.

Excercises

1. Keep score by counting taps.
2. Make the maze harder.
3. Generate the same maze twice.
"""

from random import random
import turtle
from utils import line


def draw():
    """Draw maze."""
    turtle.color('black')
    turtle.width(5)

    for x in range(-200, 200, 40):
        for y in range(-200, 200, 40):
            if random() > 0.5:
                line(x, y, x + 40, y + 40)
            else:
                line(x, y + 40, x + 40, y)

    turtle.update()


def tap(x, y):
    """Draw line and dot for screen tap."""
    if abs(x) > 198 or abs(y) > 198:
        turtle.up()
    else:
        turtle.down()

    turtle.width(2)
    turtle.color('red')
    turtle.goto(x, y)
    turtle.dot(4)


turtle.setup(420, 420, 370, 0)
turtle.hideturtle()
turtle.tracer(False)
draw()
turtle.onscreenclick(tap)
turtle.done()
```



<img src="pics\maze.png" alt="image-20220531151205008" style="zoom:50%;" />





#### memory.py 记忆力游戏

​		一个记忆力小游戏。玩家需要根据翻出的数字位置进行匹配。界面中一共有 1~32 32种数字、64个数字方格。这个游戏整体单独不大，但还是比较花费时间的。

```python
"""Memory, puzzle game of number pairs.

Exercises:

1. Count and print how many taps occur.
2. Decrease the number of tiles to a 4x4 grid.
3. Detect when all tiles are revealed.
4. Center single-digit tile.
5. Use letters instead of tiles.
"""


import turtle
import random
from utils import path

car = path('car.gif')
tiles = list(range(32)) * 2
state = {'mark': None}
hide = [True] * 64


def square(x, y):
    """Draw white square with black outline at (x, y)."""
    turtle.up()
    turtle.goto(x, y)
    turtle.down()
    turtle.color('black', 'white')
    turtle.begin_fill()
    for count in range(4):
        turtle.forward(50)
        turtle.left(90)
    turtle.end_fill()


def index(x, y):
    """Convert (x, y) coordinates to tiles index."""
    return int((x + 200) // 50 + ((y + 200) // 50) * 8)


def xy(count):
    """Convert tiles count to (x, y) coordinates."""
    return (count % 8) * 50 - 200, (count // 8) * 50 - 200


def tap(x, y):
    """Update mark and hidden tiles based on tap."""
    spot = index(x, y)
    mark = state['mark']

    if mark is None or mark == spot or tiles[mark] != tiles[spot]:
        state['mark'] = spot
    else:
        hide[spot] = False
        hide[mark] = False
        state['mark'] = None


def draw():
    """Draw image and tiles."""
    turtle.clear()
    turtle.goto(0, 0)
    turtle.shape(car)
    turtle.stamp()

    for count in range(64):
        if hide[count]:
            x, y = xy(count)
            square(x, y)

    mark = state['mark']

    if mark is not None and hide[mark]:
        x, y = xy(mark)
        turtle.up()
        turtle.goto(x + 2, y)
        turtle.color('black')
        turtle.write(tiles[mark], font=('Arial', 30, 'normal'))

    turtle.update()
    turtle.ontimer(draw, 100)


random.shuffle(tiles)
turtle.setup(420, 420, 370, 0)
turtle.addshape(car)
turtle.hideturtle()
turtle.tracer(False)
turtle.onscreenclick(tap)
draw()
turtle.done()
```



<img src="pics\memory.png" alt="image-20220531151940760" style="zoom:50%;" />





#### minesweeper.py 扫雷

​		经典游戏。不过这里的实现效果比较一般。

```python
"""Minesweeper

Exercises

1. What does the `seed(0)` function call do?
2. Change the number of bombs on the grid.
3. Change the size of the grid.
"""

from random import randrange, seed
import turtle
from utils import floor, square

seed(0)
bombs = {}
shown = {}
counts = {}


def initialize():
    """Initialize `bombs`, `counts`, and `shown` grids."""
    for x in range(-250, 250, 50):
        for y in range(-250, 250, 50):
            bombs[x, y] = False
            shown[x, y] = False
            counts[x, y] = -1

    for count in range(8):
        x = randrange(-200, 200, 50)
        y = randrange(-200, 200, 50)
        bombs[x, y] = True

    for x in range(-200, 200, 50):
        for y in range(-200, 200, 50):
            total = 0
            for i in (-50, 0, 50):
                for j in (-50, 0, 50):
                    total += bombs[x + i, y + j]
            counts[x, y] = total


def stamp(x, y, text):
    """Display `text` at coordinates `x` and `y`."""
    square(x, y, 50, 'white')
    turtle.color('black')
    turtle.write(text, font=('Arial', 50, 'normal'))


def draw():
    """Draw the initial board grid."""
    for x in range(-200, 200, 50):
        for y in range(-200, 200, 50):
            stamp(x, y, '?')


def end():
    """Draw the bombs as X's on the grid."""
    for x in range(-200, 200, 50):
        for y in range(-200, 200, 50):
            if bombs[x, y]:
                stamp(x, y, 'X')


def tap(x, y):
    """Respond to screen click at `x` and `y` coordinates."""
    x = floor(x, 50)
    y = floor(y, 50)

    if bombs[x, y]:
        end()
        return

    pairs = [(x, y)]

    while pairs:
        x, y = pairs.pop()
        stamp(x, y, counts[x, y])
        shown[x, y] = True

        if counts[x, y] == 0:
            for i in (-50, 0, 50):
                for j in (-50, 0, 50):
                    pair = x + i, y + j
                    if not shown[pair]:
                        pairs.append(pair)


turtle.setup(420, 420, 370, 0)
turtle.hideturtle()
turtle.tracer(False)
initialize()
draw()
turtle.onscreenclick(tap)
turtle.done()
```



<img src="pics\minesweeper.png" alt="image-20220531152749050" style="zoom:50%;" />





#### pacman.py 吃豆人[升级]

​		经典游戏。但是 Goast 是随机游走的 emmmmm

本实验做的改动包括：

1. **增加了目标点的大小；**
2. **相关逻辑重构。**

```python
"""Pacman, classic arcade game.

Exercises

1. Change the board.
2. Change the number of ghosts.
3. Change where pacman starts.
4. Make the ghosts faster/slower.
5. Make the ghosts smarter.
"""

from random import choice
import turtle
from utils import floor, vector

state = {'score': 0}
path = turtle.Turtle(visible=False)
writer = turtle.Turtle(visible=False)
aim = vector(5, 0)
pacman = vector(-40, -80)
ghosts = [
    [vector(-180, 160), vector(5, 0)],
    [vector(-180, -160), vector(0, 5)],
    [vector(100, 160), vector(0, -5)],
    [vector(100, -160), vector(-5, 0)],
]
# fmt: off
tiles = [
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
    0, 1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
    0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 0, 0, 0, 0,
    0, 1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
    0, 1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0,
    0, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0,
    0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 0, 0, 0, 0,
    0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
]
# fmt: on


def square(x, y):
    """Draw square using path at (x, y)."""
    path.up()
    path.goto(x, y)
    path.down()
    path.begin_fill()

    for count in range(4):
        path.forward(20)
        path.left(90)

    path.end_fill()


def offset(point):
    """Return offset of point in tiles."""
    x = (floor(point.x, 20) + 200) / 20
    y = (180 - floor(point.y, 20)) / 20
    index = int(x + y * 20)
    return index


def valid(point):
    """Return True if point is valid in tiles."""
    index = offset(point)

    if tiles[index] == 0:
        return False

    index = offset(point + 19)

    if tiles[index] == 0:
        return False

    return point.x % 20 == 0 or point.y % 20 == 0


def world():
    """Draw world using path."""
    turtle.bgcolor('black')
    path.color('blue')

    for index in range(len(tiles)):
        tile = tiles[index]

        if tile > 0:
            x = (index % 20) * 20 - 200
            y = 180 - (index // 20) * 20
            square(x, y)

            if tile == 1:
                path.up()
                path.goto(x + 10, y + 10)
                path.dot(2, 'white')


def move():
    """Move pacman and all ghosts."""
    writer.undo()
    writer.write(state['score'])

    turtle.clear()

    if valid(pacman + aim):
        pacman.move(aim)

    index = offset(pacman)

    if tiles[index] == 1:
        tiles[index] = 2
        state['score'] += 1
        x = (index % 20) * 20 - 200
        y = 180 - (index // 20) * 20
        square(x, y)

    turtle.up()
    turtle.goto(pacman.x + 10, pacman.y + 10)
    turtle.dot(20, 'yellow')

    for point, course in ghosts:
        if valid(point + course):
            point.move(course)
        else:
            options = [
                vector(5, 0),
                vector(-5, 0),
                vector(0, 5),
                vector(0, -5),
            ]
            plan = choice(options)
            course.x = plan.x
            course.y = plan.y

        turtle.up()
        turtle.goto(point.x + 10, point.y + 10)
        turtle.dot(20, 'red')

    turtle.update()

    for point, course in ghosts:
        if abs(pacman - point) < 20:
            return

    turtle.ontimer(move, 100)


def change(x, y):
    """Change pacman aim if valid."""
    if valid(pacman + vector(x, y)):
        aim.x = x
        aim.y = y


turtle.setup(420, 420, 370, 0)
turtle.hideturtle()
turtle.tracer(False)
writer.goto(160, 160)
writer.color('white')
writer.write(state['score'])
turtle.listen()
turtle.onkey(lambda: change(5, 0), 'Right')
turtle.onkey(lambda: change(-5, 0), 'Left')
turtle.onkey(lambda: change(0, 5), 'Up')
turtle.onkey(lambda: change(0, -5), 'Down')
world()
move()
turtle.done()
```



<img src="pics\pacman.png" alt="image-20220531153135246" style="zoom:50%;" />





#### paint.py 画板

​		这个程序实现了一个简易的画板。用户可以：更改颜色 、绘制图形等。

````python
"""Paint, for drawing shapes.

Exercises

1. Add a color.
2. Complete circle.
3. Complete rectangle.
4. Complete triangle.
5. Add width parameter.
"""

import turtle

from utils import vector


def line(start, end):
    """Draw line from start to end."""
    turtle.up()
    turtle.goto(start.x, start.y)
    turtle.down()
    turtle.goto(end.x, end.y)


def square(start, end):
    """Draw square from start to end."""
    turtle.up()
    turtle.goto(start.x, start.y)
    turtle.down()
    turtle.begin_fill()

    for count in range(4):
        turtle.forward(end.x - start.x)
        turtle.left(90)

    turtle.end_fill()


def circle(start, end):
    """Draw circle from start to end."""
    pass  # TODO


def rectangle(start, end):
    """Draw rectangle from start to end."""
    pass  # TODO


def triangle(start, end):
    """Draw triangle from start to end."""
    pass  # TODO


def tap(x, y):
    """Store starting point or draw shape."""
    start = state['start']

    if start is None:
        state['start'] = vector(x, y)
    else:
        shape = state['shape']
        end = vector(x, y)
        shape(start, end)
        state['start'] = None


def store(key, value):
    """Store value in state at key."""
    state[key] = value


state = {'start': None, 'shape': line}
turtle.setup(420, 420, 370, 0)
turtle.onscreenclick(tap)
turtle.listen()
turtle.onkey(turtle.undo, 'u')
turtle.onkey(lambda: turtle.color('black'), 'K')
turtle.onkey(lambda: turtle.color('white'), 'W')
turtle.onkey(lambda: turtle.color('green'), 'G')
turtle.onkey(lambda: turtle.color('blue'), 'B')
turtle.onkey(lambda: turtle.color('red'), 'R')
turtle.onkey(lambda: store('shape', line), 'l')
turtle.onkey(lambda: store('shape', square), 's')
turtle.onkey(lambda: store('shape', circle), 'c')
turtle.onkey(lambda: store('shape', rectangle), 'r')
turtle.onkey(lambda: store('shape', triangle), 't')
turtle.done()
````



<img src="pics\paint.png" alt="image-20220531153613223" style="zoom:50%;" />



#### pong.py 二维弹球

​		双侧弹球小游戏。玩家需要操控两侧的挡板接住小球，不让其撞到墙上。一个考验反应力与协调性的小游戏。

```python
"""Pong, classic arcade game.

Exercises

1. Change the colors.
2. What is the frame rate? Make it faster or slower.
3. Change the speed of the ball.
4. Change the size of the paddles.
5. Change how the ball bounces off walls.
6. How would you add a computer player?
6. Add a second ball.
"""

from random import choice, random
import turtle
from utils import vector


def value():
    """Randomly generate value between (-5, -3) or (3, 5)."""
    return (3 + random() * 2) * choice([1, -1])


ball = vector(0, 0)
aim = vector(value(), value())
state = {1: 0, 2: 0}


def move(player, change):
    """Move player position by change."""
    state[player] += change


def rectangle(x, y, width, height):
    """Draw rectangle at (x, y) with given width and height."""
    turtle.up()
    turtle.goto(x, y)
    turtle.down()
    turtle.begin_fill()
    for count in range(2):
        turtle.forward(width)
        turtle.left(90)
        turtle.forward(height)
        turtle.left(90)
    turtle.end_fill()


def draw():
    """Draw game and move pong ball."""
    turtle.clear()
    rectangle(-200, state[1], 10, 50)
    rectangle(190, state[2], 10, 50)

    ball.move(aim)
    x = ball.x
    y = ball.y

    turtle.up()
    turtle.goto(x, y)
    turtle.dot(10)
    turtle.update()

    if y < -200 or y > 200:
        aim.y = -aim.y

    if x < -185:
        low = state[1]
        high = state[1] + 50

        if low <= y <= high:
            aim.x = -aim.x
        else:
            return

    if x > 185:
        low = state[2]
        high = state[2] + 50

        if low <= y <= high:
            aim.x = -aim.x
        else:
            return

    turtle.ontimer(draw, 50)


turtle.setup(420, 420, 370, 0)
turtle.hideturtle()
turtle.tracer(False)
turtle.listen()
turtle.onkey(lambda: move(1, 20), 'w')
turtle.onkey(lambda: move(1, -20), 's')
turtle.onkey(lambda: move(2, 20), 'i')
turtle.onkey(lambda: move(2, -20), 'k')
draw()
turtle.done()

```



<img src="pics\pang.png" alt="image-20220531160250951" style="zoom:50%;" />



#### rps_game.py 剪刀石头布[新增]

​		Rocks， Paper， Scissors。经典的剪刀石头布小游戏。游戏允许玩家与电脑进行运气的比拼，支持自定义对局数目。

```python
# rock paper scissors!

import random, time

game_count = 0
win = 0
lose = 0
draw = 0
print("Welcome to Rock-Paper-Scissors Game!")
total = int(input("Please input the total game rounds (odd):\n[input]:"))
if total % 2 == 0:
    total = total + 1

while game_count < total:
    
    print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n=============================================================")
    print("\nRound {} / {}".format(game_count + 1, total))

    while True:
        player = (input("Please make your choice: Rock、 Papar or Scissors\n")).upper()
        if player == "R":
            player = "ROCK"
        if player == "P":
            player = "PAPER"
        if player == "S":
            player = "SCISSORS"
        if player == "ROCK" or player == "PAPER" or player == "SCISSORS":
            break
        print("You can't choose that. Try again.")


    choice = ["PAPER", "ROCK", "SCISSORS"]
    computer = choice[random.randint(0, 2)]

    print("Your choice was: {}, while computer chose {}.".format(player, computer))
    if player == computer:
        draw += 1
        print("This is a draw!")
        
    elif (player == "ROCK" and computer == "PAPER") or (player == "PAPER" and computer == "SCISSORS") or (player == "SCISSORS" and computer == "ROCK"):
        lose += 1
        print("Opps, you lose.")
        
    else:
        win += 1
        print("Great! You got it!")
    time.sleep(0.5)
    game_count += 1

    if lose == (total + 1) // 2 or win == (total + 1) // 2:      
        break

print("\n\n=============================================================")
print("Results:")
print("    win --- {} times".format(win))
print("    lose --- {} times".format(lose))
print("    draw --- {} times".format(draw))
print("    total --- {} times".format(game_count))
print("=============================================================\n")
if lose > win:
    print("You lose. Maybe next time will be better.")
elif lose < win:
    print("You win! Congratulations!")
else:
    print("Just soso.")
print("\n\n")
```

一次对局的过程如下：

```
Welcome to Rock-Paper-Scissors Game!
Please input the total game rounds (odd):
[input]:5

=============================================================
Round 1 / 5
Please make your choice: Rock、 Papar or Scissors
R
Your choice was: ROCK, while computer chose PAPER.
Opps, you lose.


=============================================================
Round 2 / 5
Please make your choice: Rock、 Papar or Scissors
P
Your choice was: PAPER, while computer chose PAPER.
This is a draw!


=============================================================
Round 3 / 5
Please make your choice: Rock、 Papar or Scissors
P
Your choice was: PAPER, while computer chose PAPER.
This is a draw!


=============================================================
Round 4 / 5
Please make your choice: Rock、 Papar or Scissors
P
Your choice was: PAPER, while computer chose SCISSORS.
Opps, you lose.


=============================================================
Round 5 / 5
Please make your choice: Rock、 Papar or Scissors
R
Your choice was: ROCK, while computer chose SCISSORS.
Great! You got it!


=============================================================
Results:
    win --- 1 times
    lose --- 2 times
    draw --- 2 times
    total --- 5 times
=============================================================

You lose. Maybe next time will be better.
```







#### simmonsays.py 顺序记忆[升级]

​		记忆力小游戏 again。玩家需要记住色块亮起的顺序，并按照相应的顺序点击色块。顺序序列的长度每次递增。

本实验进行的改动如下：

1. **将色块数量增加为 9 个；**
2. **随着序列长度的增加，闪烁的时间会逐渐变短；**
3. **增加了玩家提示内容；**
4. **其他相关的改动。**

```python
"""Simon Says
 
Exercises

1. Speed up tile flash rate.
2. Add more tiles.
"""

from random import choice
from time import sleep
import turtle

from utils import floor, square, vector

pattern = []
guesses = []
tiles = {
    vector(-100, -100): ('red', 'dark red'),
    vector(-100, -300): ('blue', 'dark blue'),
    vector(-300, -100): ('green', 'dark green'),
    vector(-300, -300): ('yellow', 'khaki'),
    vector(-100, 100): ('mediumorchid', 'purple'),
    vector(-300, 100): ('mediumturquoise', 'lightseagreen'),
    vector(100, -300): ('orange', 'wheat'),
    vector(100, -100): ('gray', 'darkgray'),
    vector(100, 100): ('deeppink', 'hotpink'),
}


def grid():
    """Draw grid of tiles."""
    square(-100, -100, 200, 'dark red')
    square(-100, -300, 200, 'dark blue')
    square(-300, -100, 200, 'dark green')
    square(-300, -300, 200, 'khaki')
    square(-100, 100, 200, 'purple')
    square(-300, 100, 200, 'lightseagreen')
    square(100, -300, 200, 'wheat')
    square(100, -100, 200, 'darkgray')
    square(100, 100, 200, 'hotpink')
    turtle.update()


def flash(tile):
    """Flash tile in grid."""
    glow, dark = tiles[tile]
    square(tile.x, tile.y, 200, glow)
    turtle.update()
    if len(pattern) > 5:
        sleep(0.4)
    elif len(pattern) > 10:
        sleep(0.3)
    elif len(pattern) > 15:
        sleep(0.2)
    else:
        sleep(0.5)
    square(tile.x, tile.y, 200, dark)
    turtle.update()
    if len(pattern) > 5:
        sleep(0.4)
    elif len(pattern) > 10:
        sleep(0.3)
    elif len(pattern) > 15:
        sleep(0.2)
    else:
        sleep(0.5)


def grow():
    """Grow pattern and flash tiles."""
    tile = choice(list(tiles))
    pattern.append(tile)

    print("\n\n\n\n\n\n\n\n\n\nNext round!")
    sleep(0.5)
    if len(pattern) == 6 or len(pattern) == 11 or len(pattern) == 16:
        print("Speed up!")
        sleep(1)
    print("Ready to flash the patterns in 3...")
    sleep(1)
    print("Ready to flash the patterns in 2...")
    sleep(1)
    print("Ready to flash the patterns in 1...")
    sleep(1)
    for tile in pattern:
        flash(tile)

    print('Pattern length:', len(pattern))
    guesses.clear()


def tap(x, y):
    """Respond to screen tap."""
    turtle.onscreenclick(None)
    x = floor(x, 100) 
    y = floor(y, 100) 
    if x % 200 == 0:
        x -= 100
    if y % 200 == 0:
        y -= 100
    tile = vector(x, y)
    index = len(guesses)

    if tile != pattern[index]:
        print("Opps! This is wrong!")
        exit()

    print("Correct!")
    

    guesses.append(tile)
    flash(tile)

    if len(guesses) == len(pattern):
        grow()

    turtle.onscreenclick(tap)


def start(x, y):
    """Start game."""
    grow()
    turtle.onscreenclick(tap)


turtle.setup(750, 750, 100, 100)
turtle.hideturtle()
turtle.tracer(False)
grid()
turtle.onscreenclick(start)
turtle.done()
```

<img src="pics\simon.png" alt="image-20220627184038012" style="zoom:50%;" />





#### snake.py 贪吃蛇[升级]

​		经典游戏。本次实验进行的改动包括：

1. **加快了贪吃蛇的移动速度；**
2. **取消了边界的限制，现在蛇可以自由地跨过边界，来到另外一边；**
3. **增加了空格键暂停与恢复功能。**

```python
"""Snake, classic arcade game.

Exercises

1. How do you make the snake faster or slower?
2. How can you make the snake go around the edges?
3. How would you move the food?
4. Change the snake to respond to mouse clicks.
"""

from random import randrange
from tkinter.tix import Tree
import turtle
import time
from utils import vector


food = vector(0, 0)
snake = [vector(10, 0)]
aim = vector(0, -10)
game_on = 1

def change(x, y):
    """Change snake direction."""
    aim.x = x
    aim.y = y

def stop():
    global game_on 
    if game_on == 1:
        game_on = 0
    else:
        game_on = 1


def square(x, y, size, name):
    """
    Draw square at `(x, y)` with side length `size` and fill color `name`.

    The square is oriented so the bottom left corner is at (x, y).

    """
    import turtle

    turtle.up()
    turtle.goto(x, y)
    turtle.down()
    turtle.color(name)
    turtle.begin_fill()

    for count in range(4):
        turtle.forward(size)
        turtle.left(90)

    turtle.end_fill()


def inside(head):
    """Return True if head inside boundaries."""
    return -200 < head.x < 190 and -200 < head.y < 190

def across(head):
    '''Make the head jump across the boundaries.'''
    if head.x < -200:
        head.x = 190
        return
    if head.x > 190:
        head.x = -200
        return
    if head.y < -200:
        head.y = 190
        return
    if head.y > 190:
        head.y = -200
        return


def move():
    global game_on

    if game_on == 1:
        """Move snake forward one segment."""
        head = snake[-1].copy()
        head.move(aim)

        across(head)
        # if not inside(head) or head in snake:
        if head in snake:
            square(head.x, head.y, 9, 'red')
            turtle.update()
            return

        snake.append(head)

        if head == food:
            print('Snake:', len(snake))
            food.x = randrange(-15, 15) * 10
            food.y = randrange(-15, 15) * 10
        else:
            snake.pop(0)

        turtle.clear()

        for body in snake:
            square(body.x, body.y, 9, 'black')

        square(food.x, food.y, 9, 'green')
        turtle.update()

    turtle.ontimer(move, 50)


turtle.setup(420, 420, 370, 0)
turtle.hideturtle()
turtle.tracer(False)
turtle.listen()
move()

turtle.onkey(lambda: change(10, 0), 'Right')
turtle.onkey(lambda: change(-10, 0), 'Left')
turtle.onkey(lambda: change(0, 10), 'Up')
turtle.onkey(lambda: change(0, -10), 'Down')
turtle.onkey(lambda: stop(), 'space')

turtle.done()
```



<img src="pics\snake.png" alt="image-20220627135950191" style="zoom:50%;" />





#### tictactoe.py 井字棋

​		双人小游戏之井字棋。

```python
"""Tic Tac Toe

Exercises

1. Give the X and O a different color and width.
2. What happens when someone taps a taken spot?
3. How would you detect when someone has won?
4. How could you create a computer player?
"""

import turtle

from utils import line


def grid():
    """Draw tic-tac-toe grid."""
    line(-67, 200, -67, -200)
    line(67, 200, 67, -200)
    line(-200, -67, 200, -67)
    line(-200, 67, 200, 67)


def drawx(x, y):
    """Draw X player."""
    line(x, y, x + 133, y + 133)
    line(x, y + 133, x + 133, y)


def drawo(x, y):
    """Draw O player."""
    turtle.up()
    turtle.goto(x + 67, y + 5)
    turtle.down()
    turtle.circle(62)


def floor(value):
    """Round value down to grid with square size 133."""
    return ((value + 200) // 133) * 133 - 200


state = {'player': 0}
players = [drawx, drawo]


def tap(x, y):
    """Draw X or O in tapped square."""
    x = floor(x)
    y = floor(y)
    player = state['player']
    draw = players[player]
    draw(x, y)
    turtle.update()
    state['player'] = not player


turtle.setup(420, 420, 370, 0)
turtle.hideturtle()
turtle.tracer(False)
grid()
turtle.update()
turtle.onscreenclick(tap)
turtle.done()
```

<img src="pics\tictactoe.png" alt="image-20220531161657074" style="zoom:50%;" />





#### tiles.py 数字华容道[升级]

​		经典游戏。玩家需要将数字按照升序进行排列。

本实验进行的改动：

1. **增加了鼠标点击计数器。**
2. **优化逻辑判断。**

```python
"""Tiles, number swapping game.

Exercises

1. Track a score by the number of tile moves.
2. Permit diagonal squares as neighbors.
3. Respond to arrow keys instead of mouse clicks.
4. Make the grid bigger.
"""

import random
import turtle

from utils import floor, vector

tiles = {}
neighbors = [
    vector(100, 0),
    vector(-100, 0),
    vector(0, 100),
    vector(0, -100),
]

writer = turtle.Turtle(visible=False)
count = 0

def load():
    """Load tiles and scramble."""
    count = 1

    for y in range(-200, 200, 100):
        for x in range(-200, 200, 100):
            mark = vector(x, y)
            tiles[mark] = count
            count += 1

    tiles[mark] = None

    for count in range(1000):
        neighbor = random.choice(neighbors)
        spot = mark + neighbor

        if spot in tiles:
            number = tiles[spot]
            tiles[spot] = None
            tiles[mark] = number
            mark = spot


def square(mark, number):
    """Draw white square with black outline and number."""
    turtle.up()
    turtle.goto(mark.x, mark.y)
    turtle.down()

    turtle.color('black', 'white')
    turtle.begin_fill()
    for count in range(4):
        turtle.forward(99)
        turtle.left(90)
    turtle. end_fill()

    if number is None:
        return
    elif number < 10:
        turtle.forward(20)

    turtle.write(number, font=('Arial', 60, 'normal'))


def tap(x, y):
    global count
    """Swap tile and empty square."""
    x = floor(x, 100)
    y = floor(y, 100)
    mark = vector(x, y)

    count += 1

    writer.undo()
    writer.goto(260, 160)
    writer.color('black')
    writer.write(count)

    for neighbor in neighbors:
        spot = mark + neighbor

        if spot in tiles and tiles[spot] is None:
            number = tiles[mark]
            tiles[spot] = number
            square(spot, number)
            tiles[mark] = None
            square(mark, None)


def draw():
    """Draw all tiles."""
    for mark in tiles:
        square(mark, tiles[mark])
    turtle.update()


turtle.setup(600, 420, 370, 0)
turtle.hideturtle()
turtle.tracer(False)
load()
draw()
turtle.onscreenclick(tap)
turtle.done()
```



<img src="pics\tiles.png" alt="image-20220627153843986" style="zoom:50%;" />



#### tron.py 领土战争[升级]

​		双人小游戏。红蓝双方需要控制自己的像素点移动，占领尽可能多的区域。玩家不能进入不属于自己颜色的区域。游戏的核心是：活到最后！

​		本实验进行的改动包括：

1. **优化了控制方式，由左右转弯变成了四向控制，更加符合日常习惯；**
2. **允许玩家穿越边界，来到对侧，增加了游戏的可玩性。**

```python
"""Tron, classic arcade game.

Exercises

1. Make the tron players faster/slower.
2. Stop a tron player from running into itself.
3. Allow the tron player to go around the edge of the screen.
4. How would you create a computer player?
"""

import turtle

from utils import square, vector

p1xy = vector(-100, 0)
p1aim = vector(4, 0)
p1body = set()

p2xy = vector(100, 0)
p2aim = vector(-4, 0)
p2body = set()

def change(aim, x, y):
    """Change snake direction."""
    aim.x = x
    aim.y = y

def inside(head):
    """Return True if head inside screen."""
    return -200 < head.x < 200 and -200 < head.y < 200

def across(head):
    '''Make the head jump across the boundaries.'''
    if head.x < -200:
        head.x = 200
        return
    if head.x > 200:
        head.x = -200
        return
    if head.y < -200:
        head.y = 200
        return
    if head.y > 200:
        head.y = -200
        return


def draw():
    """Advance players and draw game."""
    p1xy.move(p1aim)
    across(p1xy)
    
    p1head = p1xy.copy()

    p2xy.move(p2aim)
    across(p2xy)

    p2head = p2xy.copy()
    
    
    if p1head in p2body:
        print('Player red wins!')
        return

    if p2head in p1body:
        print('Player blue wins!')
        return

    p1body.add(p1head)
    p2body.add(p2head)

    square(p1xy.x, p1xy.y, 3, 'blue')
    square(p2xy.x, p2xy.y, 3, 'red')
    turtle.update()
    turtle.ontimer(draw, 50)


turtle.setup(420, 420, 370, 0)
turtle.hideturtle()
turtle.tracer(False)
turtle.listen()

turtle.onkey(lambda: change(p1aim, 4, 0), 'Right')
turtle.onkey(lambda: change(p1aim, -4, 0), 'Left')
turtle.onkey(lambda: change(p1aim, 0, 4), 'Up')
turtle.onkey(lambda: change(p1aim, 0, -4), 'Down')

turtle.onkey(lambda: change(p2aim, 4, 0), 'd')
turtle.onkey(lambda: change(p2aim, -4, 0), 'a')
turtle.onkey(lambda: change(p2aim, 0, 4), 'w')
turtle.onkey(lambda: change(p2aim, 0, -4), 's')

draw()
turtle.done()
```



<img src="pics\tron.png" alt="image-20220531163244268" style="zoom:50%;" />



