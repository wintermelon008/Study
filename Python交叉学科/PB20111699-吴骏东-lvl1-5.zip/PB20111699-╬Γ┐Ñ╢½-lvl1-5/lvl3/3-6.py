# Level 3.6（加 1 分）【物理】- 接【数学】Level 2.3 野外彩弹 CS 游戏，考虑重 力和空气阻力影响，给定发射点坐标(x0,y0,z0)，落点坐标(x1,y1,z1)，空气阻力
# f（矢量，以(fx,fy,fz)表示），及彩弹的初速度大小 v0（标量数值），使用
# numpy、math 库等工具求解满足给定起点、落点、空气阻力和初速的发射仰角
# 提示 1：默认 g=9.8 为常数；如果初速度过小，解可能不存在
# 提示 2：弹道计算机的雏形

from cmath import sqrt
from scipy.optimize import fsolve
import numpy as np
import decimal as dec


g = 9.8
fx, fy, fz = map(float, input("Please input the \\vec{f}(Divided by \" \")\n[input]:").split())
x0, y0, z0 = map(float, input("Please input the launch point (Divided by \" \")\n[input]:").split())
x1, y1, z1 = map(float, input("Please input the target point (Divided by \" \")\n[input]:").split())
m = float(input("Please input the mass\n[input]:"))
v0 = float(input("Please input the initial speed\n[input]:"))

def func(list):
    vx = list[0]
    vy = list[1]
    vz = list[2]
    t = list[3]
    return [
        m//fx*vx*(1-np.e**(-fx//m*t))+x0-x1,
        m//fy*vy*(1-np.e**(-fy//m*t))+y0-y1,
        m//fz*(vz+m*g//fz)*(1-np.e**(-fz//m*t))-m*g//fz*t+z0-z1,
        vx**2+vy**2+vz**2-v0**2
    ]

vx0 = 1
vy0 = 1
vz0 = 1
t0 = 0.1
i = 0
count = 1
ans_list = []


while i < 100:
    start = start = [vx0, vy0, vz0, t0 + 0.1 * i]
    i += 1
    ans = fsolve(func, start)
    if ans[3] < 0:
        continue
    t_opt = dec.Decimal(str(ans[3])).quantize(dec.Decimal("0.001"), rounding="ROUND_HALF_UP")
    if t_opt not in ans_list:
        print("Ans {}: {}".format(count, ans))
        print("Theta = {} (degree)".format(np.arctan(np.real(v0/sqrt(abs(v0**2 - ans[2]**2)))) / np.pi * 180))
        count += 1
        ans_list.append(t_opt)
    




