### Level 3

#### 题目

Level 3.6（加 1 分）【物理】- 接【数学】Level 2.3 野外彩弹 CS 游戏，考虑重力和空气阻力影响，给定发射点坐标 (x0,y0,z0)，落点坐标 (x1,y1,z1)，空气阻力 f（矢量，以 (fx,fy,fz) 表示），及彩弹的初速度大小 v0（标量数值），使用 numpy、math 库等工具求解满足给定起点、落点、空气阻力和初速的发射仰角。

提示 1：默认 g=9.8 为常数；如果初速度过小，解可能不存在

提示 2：弹道计算机的雏形

#### 求解

我们构建如下的物理模型：假设空气阻力的形式为
$$
\vec{F}=-(f_xv_x, f_yv_y, f_zv_z)
$$
在各向均匀的空间中，应有
$$
f_x = f_y = f_z = k
$$
本题中，我们先认为各个方向上的空气阻力系数不相同。由运动的可分解性，可对 x、y 两个方向分别进行考虑。以 x 方向为例，我们有：
$$
m\ddot{x} = -f_x\dot{x}\\ 
\Rightarrow \frac{\mathrm{d} \dot{x}}{\dot{x}} = -\frac{f_x}{m}\mathrm{d}t \\ 
\Rightarrow v_x = \dot{x} = v_{x0}\exp\left({-\frac{f_x}{m}t}\right)
$$
对上式两边积分，我们可得
$$
x = x_0 - \frac{m}{f_x}v_{x0}\left[\exp\left({-\frac{f_x}{m}t}\right) - 1\right]
\tag{1}
$$
同理可得
$$
y = y_0 - \frac{m}{f_y}v_{y0}\left[\exp\left({-\frac{f_y}{m}t}\right) - 1\right]
\tag{2}
$$
在 z 方向上，我们有
$$
m\ddot{z} = -f_z\dot{z} - mg \\
\Rightarrow \mathrm{d} \left(\dot{z} + \frac{mg}{f_z}\right) = -\frac{f_z}{m}\left(\dot{z} + \frac{mg}{f_z}\right)\mathrm{d}t \\
\Rightarrow v_z = \left(v_{z0} + \frac{mg}{f_z}\right)\exp{\left(-\frac{f_z}{m}t\right)} - \frac{mg}{f_z}
$$
对上式两边积分，我们可得
$$
z = z_0 - \frac{m}{f_z}\left(v_{z0} + \frac{mg}{f_z}\right)\left[\exp{\left(-\frac{f_z}{m}t\right)} - 1\right]- \frac{mg}{f_z}t
\tag{3}
$$
根据式（1）~（3），代入落点坐标 (x1, y1, z1) ，有
$$
\left\{\begin{matrix}
 x_1 - x_0 = \frac{m}{f_x}v_{x0}\left[1- \exp\left({-\frac{f_x}{m}t}\right)\right] \\
 y_1 - y_0 = \frac{m}{f_y}v_{y0}\left[1- \exp\left({-\frac{f_y}{m}t}\right)\right]\\
 z_1 - z_0 = \frac{m}{f_z}\left(v_{z0} + \frac{mg}{f_z}\right)\left[1- \exp{\left(-\frac{f_z}{m}t\right)} \right]- \frac{mg}{f_z}t\\

\end{matrix}\right.
$$
并且有
$$
v_{x0}^2 + v_{y0}^2 + v_{z0}^2 = v_0^2
$$


解上面四个方程，可求得 $v_x, v_y, v_z, t$ 四个参数。则目标的发射角度为（取高于水平方向为正方向）
$$
\tan\theta = \frac{v_{z0}}{\sqrt{v_0^2-v_{z_0}^2}}
$$

#### 代码实现

本实验中使用了 numpy、scipy、decimal 库进行求解。代码如下：

```python
# Level 3.6（加 1 分）【物理】- 接【数学】Level 2.3 野外彩弹 CS 游戏，考虑重 力和空气阻力影响，给定发射点坐标(x0,y0,z0)，落点坐标(x1,y1,z1)，空气阻力
# f（矢量，以(fx,fy,fz)表示），及彩弹的初速度大小 v0（标量数值），使用
# numpy、math 库等工具求解满足给定起点、落点、空气阻力和初速的发射仰角
# 提示 1：默认 g=9.8 为常数；如果初速度过小，解可能不存在
# 提示 2：弹道计算机的雏形

from cmath import sqrt
from scipy.optimize import fsolve
import numpy as np
import decimal as dec

g = 9.8
fx, fy, fz = map(float, input("Please input the \\vec{f}(Divided by \" \")\n[input]:").split())
# 输入空气阻力的参数
x0, y0, z0 = map(float, input("Please input the launch point (Divided by \" \")\n[input]:").split())
# 输入发射点坐标
x1, y1, z1 = map(float, input("Please input the target point (Divided by \" \")\n[input]:").split())
# 输入落点坐标
m = float(input("Please input the mass\n[input]:"))
# 输入质量
v0 = float(input("Please input the initial speed\n[input]:"))
# 输入初速度大小

def func(list):
    vx = list[0]
    vy = list[1]
    vz = list[2]
    t = list[3]
    return [
        m//fx*vx*(1-np.e**(-fx//m*t))+x0-x1,
        m//fy*vy*(1-np.e**(-fy//m*t))+y0-y1,
        m//fz*(vz+m*g//fz)*(1-np.e**(-fz//m*t))-m*g//fz*t+z0-z1,
        vx**2+vy**2+vz**2-v0**2
    ]

vx0 = 1
vy0 = 1
vz0 = 1
t0 = 0.1
i = 0
count = 1
ans_list = []

# 采用了循环进行不同初值求解，尽可能覆盖到所有解情况
while i < 100:
    start = start = [vx0, vy0, vz0, t0 + 0.1 * i]
    i += 1
    ans = fsolve(func, start)
    if ans[3] < 0:
        continue
    t_opt = dec.Decimal(str(ans[3])).quantize(dec.Decimal("0.001"), rounding="ROUND_HALF_UP")
    if t_opt not in ans_list:
        print("Ans {}: {}".format(count, ans))
        # 输出结果，为 [vx, vy, vz, t]
        print("Theta = {} (degree)".format(np.arctan(np.real(v0/sqrt(abs(v0**2 - ans[2]**2)))) / np.pi * 180))
        # 输出发射仰角
        count += 1
        ans_list.append(t_opt)
```

#### 输入

初始条件，包括发射点坐标、落点坐标、质量、初速度大小、空气阻力参数。

#### 输出

所有符合条件的发射仰角。

#### 示例

```
Example 1:

Please input the \vec{f}(Divided by " ")		// 空气阻力参数
[input]:1 1 1
Please input the launch point (Divided by " ")		// 发射点
[input]:0 0 0
Please input the target point (Divided by " ")		// 落点
[input]:1 1 1
Please input the mass	// 质量
[input]:1
Please input the initial speed	// 初速度
[input]:10
Ans 1: [1.27732169 1.27732169 9.83549178 1.52734257]	// 从左到右依次为 vx vy vz t
Theta = 79.76048035251111 (degree)
Ans 2: [5.44139938 5.44139938 6.38610567 0.20306676]
Theta = 52.42063546848804 (degree)
// 各向同性，解一般为两个


Example 2:

Please input the \vec{f}(Divided by " ")
[input]:5 5 5
Please input the launch point (Divided by " ")
[input]:0 0 0
Please input the target point (Divided by " ")
[input]:10 10 10
Please input the mass
[input]:1
Please input the initial speed
[input]:1
D:\Python\lib\site-packages\scipy\optimize\_minpack_py.py:175: RuntimeWarning: The iteration is not making good progress, as measured by the 
  improvement from the last ten iterations.
  warnings.warn(msg, RuntimeWarning)
Ans 1: [1.  1.  1.  0.3]	// 无解的情况
Traceback (most recent call last):
  File "d:\0-Programmingformelon\python\level1-3\3-6.py", line 50, in <module>
    print("Theta = {} (degree)".format(np.arctan(np.real(v0/sqrt(abs(v0**2 - ans[2]**2)))) / np.pi * 180))
ZeroDivisionError: complex division by zero


Example 3:

Please input the \vec{f}(Divided by " ")
[input]:1 2 3		// 不是各向同性，解就会很多
Please input the launch point (Divided by " ")
[input]:0 0 0
Please input the target point (Divided by " ")
[input]:1 1 1
Please input the mass
[input]:1
Please input the initial speed
[input]:10
Ans 1: [5.15010894 8.57170016 0.05527545 0.05595396]
Theta = 45.000437656979706 (degree)
Ans 2: [6.1788159  2.0935977  7.57889162 0.06398459]
Theta = 56.88024036572873 (degree)
Ans 3: [4.34131074 3.99240231 8.07566999 0.04322956]
Theta = 59.46892313937881 (degree)
Ans 4: [3.84816926 -2.14521704  8.9772329   0.03132328]
Theta = 66.22364163336125 (degree)
Ans 5: [3.83641201 1.53287667 9.10690451 0.03177325]
Theta = 67.55499607694532 (degree)
Ans 6: [ 4.28472895 -9.03183756 -0.26899128  0.0422043 ]
Theta = 45.01036802918545 (degree)
Ans 7: [ 5.37147091 -5.42431199 -6.4598546   0.05799376]
Theta = 52.643706215046414 (degree)
Ans 8: [ 5.22180931 -5.51486258 -6.5051175   0.05689277]
Theta = 52.78346797143463 (degree)
Ans 9: [ 3.14312457e+00 -9.20789595e+00  2.31008969e+00  6.50042349e-03]
Theta = 45.78545306203987 (degree)
Ans 10: [4.95698817 1.22431179 8.59834416 0.05356604]
Theta = 62.95237111368378 (degree)
Ans 11: [ 3.40811178 -9.2689922  -1.5719605   0.01733392]
Theta = 45.35839050168617 (degree)
Ans 12: [ 4.69666193 -7.95703376 -3.82453324  0.04970215]
Theta = 47.26284528939424 (degree)
Ans 13: [ 4.7553113  -3.25178171  8.17422181  0.05074304]
Theta = 60.0563778544339 (degree)
Ans 14: [3.01743820e+00 2.39386674e+00 9.22854441e+00 6.01291819e-04]
Theta = 68.93586441633936 (degree)
Ans 15: [3.79410272 0.62250555 9.23158543 0.02959054]
Theta = 68.9722697828688 (degree)
Ans 16: [6.0391705  1.34715039 7.85577869 0.06328437]
Theta = 58.2523189188006 (degree)
Ans 17: [ 6.81649097 -0.05320895  7.31657278  0.06616076]
Theta = 55.71881484849564 (degree)
Ans 18: [4.83784703 1.81425582 8.56104704 0.05224231]
Theta = 62.6699700258407 (degree)
Ans 19: [ 5.51550564 -8.10477093  1.97425927  0.05997185]
Theta = 45.56943862212352 (degree)
Ans 20: [ 4.42000879 -8.92751078 -0.87465083  0.04506434]
Theta = 45.110001226301804 (degree)
Ans 21: [ 3.73203647 -2.62461536  8.89869206  0.02788646]
Theta = 65.47678217803116 (degree)
Ans 22: [ 4.00986219 -1.13015844  9.09107474  0.03493983]
Theta = 67.385262581239 (degree)
Ans 23: [ 4.01616578 -5.09496833 -7.61003744  0.03577195]
Theta = 57.02661033102674 (degree)
Ans 24: [ 4.14684791 -8.95171242  1.63323257  0.03986577]
Theta = 45.387260496467434 (degree)
Ans 25: [ 3.95045494 -6.6256048  -6.36376865  0.03418095]
Theta = 52.3541850377621 (degree)
Ans 26: [ 3.34231963  2.02341456 -9.20538776  0.01424973]
Theta = 68.66183823025445 (degree)
```

