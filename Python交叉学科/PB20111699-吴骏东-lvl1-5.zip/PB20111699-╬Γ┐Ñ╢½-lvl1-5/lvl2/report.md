### Level 2

#### 题目

Level 2.11.【生化】DNA 转录 RNA 过程模拟：在 RNA 转录过程中，一条 DNA 链用作模板，mRNA 通过一次复制一个核苷酸来构建 RNA 链，转录过程中使用尿嘧啶代替胸腺嘧啶。使用字符代表碱基，DNA 字符串含有 A，C， G，T，RNA 字符串含有 A，C，G，U。现有 DNA 字符串 s，将碱基 T 替换为碱基 U，求转录后的 RNA。如
$$
\text{ DNA（ATGGAACTTGACTACGTAAATT）}\rightarrow \text{ RNA（AUGGAACUUGACUACGUAAAUU）}
$$


#### 求解思路

进行一个较为简单的字符替换即可。

#### 代码实现

```python
# Level 2.11.【生化】DNA 转录 RNA 过程模拟：在 RNA 转录过程中，一条 DNA 链用作模板，mRNA 通过一次复制一个核苷酸来构建 RNA 链，转录过程中使用尿嘧啶代替胸腺嘧啶。
# 使用字符代表碱基，DNA 字符串含有 A，C， G，T，RNA 字符串含有 A，C，G，U。现有 DNA 字符串 s，将碱基 T 替换为碱基 U，求转录后的 RNA。

sequence = input('Please input the DNA sequence \n[input]:')
sequence = (sequence.upper()).replace("T", "U").replace(" ", "")
print("The corresponding mRNA sequence is:")
print(sequence)
```

#### 输入

标准的 DNA 模板序列。由 A、T、G、C 组成，不应有额外的空格，不区分大小写，不考虑启动子等其他因素对转录结果的影响。

#### 输出

以另外一条 DNA 为直接模板转录的 mRNA 序列。

#### 示例

```
Example 1:
Please input the DNA sequence 
[input]:ATGGAACTTGACTACGTAAATT
The corresponding mRNA sequence is:
AUGGAACUUGACUACGUAAAUU

Example 2:
Please input the DNA sequence 
[input]:gggtgggtcggcgaggcctgtcggacactagtaacaccagtttaaacccgacagtccttgcttcacaaccacctcgttaggtggtgggtcactcgaagatcattacgccgtgtcctcgtattagatccaactaaccccctttactaaaacaacccgggttcacggaatgtcgccgaaaagacgagacgacactatcaaccacagtgtttcgtcgacaggtaccgacagcgattactatcgaaccgtcaatcagcactccatatagtagttgcataggtaacattggtaacccgccataagaatgagtcgcgcctagtagcctgcacggaacgccgtcgattccggccgcaaaaagattgcagtgcccgggcatgcggggggcgcccataatggtatacaccgggcaacatcgtgaccctctggccccctgcccgatctgatggtgataacgtcggaataccttgggttcattagtcctgatacaataagtattaacacatgactataagtcgcgatctcaagtaagaccagccaagggtgcaaaaattcgttgaggccactactaaggcatggtagacaatacctgcggtgtattggtctcagcaggcattgcaaacagattgcaatgctcctatgatattaggcgttattggcatgtccgcgcactccatgtgtggctatgccatcacttgattcacgccagaaatcgagaggaagcagttgtaggtcgttctgtaaaactcgtaataatgagacgacagccgaaaaccaatagcaaaatagaaaatagcgaatttgatttaattgaagtaaggtaatcaatagggcatcgtgttaggctgggtcgattcatgtggatgagtgaccctcgatactggtattaagggccatatcacctattatgcacaaccctgcactgaggtagtgttgcttggcagctcgttttcacgcggttctacgtgcgcagagcctgtaaacgctcaagtaatctctagtggtc
The corresponding mRNA sequence is:
GGGUGGGUCGGCGAGGCCUGUCGGACACUAGUAACACCAGUUUAAACCCGACAGUCCUUGCUUCACAACCACCUCGUUAGGUGGUGGGUCACUCGAAGAUCAUUACGCCGUGUCCUCGUAUUAGAUCCAACUAACCCCCUUUACUAAAACAACCCGGGUUCACGGAAUGUCGCCGAAAAGACGAGACGACACUAUCAACCACAGUGUUUCGUCGACAGGUACCGACAGCGAUUACUAUCGAACCGUCAAUCAGCACUCCAUAUAGUAGUUGCAUAGGUAACAUUGGUAACCCGCCAUAAGAAUGAGUCGCGCCUAGUAGCCUGCACGGAACGCCGUCGAUUCCGGCCGCAAAAAGAUUGCAGUGCCCGGGCAUGCGGGGGGCGCCCAUAAUGGUAUACACCGGGCAACAUCGUGACCCUCUGGCCCCCUGCCCGAUCUGAUGGUGAUAACGUCGGAAUACCUUGGGUUCAUUAGUCCUGAUACAAUAAGUAUUAACACAUGACUAUAAGUCGCGAUCUCAAGUAAGACCAGCCAAGGGUGCAAAAAUUCGUUGAGGCCACUACUAAGGCAUGGUAGACAAUACCUGCGGUGUAUUGGUCUCAGCAGGCAUUGCAAACAGAUUGCAAUGCUCCUAUGAUAUUAGGCGUUAUUGGCAUGUCCGCGCACUCCAUGUGUGGCUAUGCCAUCACUUGAUUCACGCCAGAAAUCGAGAGGAAGCAGUUGUAGGUCGUUCUGUAAAACUCGUAAUAAUGAGACGACAGCCGAAAACCAAUAGCAAAAUAGAAAAUAGCGAAUUUGAUUUAAUUGAAGUAAGGUAAUCAAUAGGGCAUCGUGUUAGGCUGGGUCGAUUCAUGUGGAUGAGUGACCCUCGAUACUGGUAUUAAGGGCCAUAUCACCUAUUAUGCACAACCCUGCACUGAGGUAGUGUUGCUUGGCAGCUCGUUUUCACGCGGUUCUACGUGCGCAGAGCCUGUAAACGCUCAAGUAAUCUCUAGUGGUC
```

#### 补充说明

写题目的时候有一个疑问，即题目提供的 DNA 是模板链还是其补链。本实验中按照模板链的补链理解，故只需要进行碱基对的替换即可。如果为模板链，则需要对本实验中的结果进行碱基对替换，即 A-U、U-A、G-C、C-G。具体实现此处不再展开。