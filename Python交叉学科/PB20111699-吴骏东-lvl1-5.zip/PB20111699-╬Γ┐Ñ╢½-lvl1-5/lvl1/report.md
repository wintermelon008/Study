### Level 1 

> PB20111699
>
> 吴骏东

#### 题目

Level 1.10【生化】分子量计算：给定一个只含 C，H，O，N 的化学分子式，输出它的分子量。

#### 求解思路

可以采用字符串处理模式，让用户输入一个字符串，根据其内容进行相应的处理。

#### 代码实现

```python
# Level 1.10【生化】分子量计算：给定一个只含 C，H，O，N 的化学分子式，
# 输出它的分子量

molecular = input('Please input the molecular formula \n[input]:')
molecular = molecular.upper()
length = len(molecular)
i = 0
atoms = [0, 0, 0, 0]

# 循环读入字符
while (i < length):
    if molecular[i] == 'C':
        # 针对每一个元素，按照字符的形式读取后面的数字。该方法理论上可以支持任意长度的数值。
        j = 1
        temp = 0
        while i + j < length and molecular[i + j] >= '0' and molecular[i + j] <= '9':
            temp = temp * 10 + int(molecular[i + j])
            j = j + 1
        atoms[0] += temp
        i += j
    
    elif molecular[i] == 'H':
        j = 1
        temp = 0
        while i + j < length and molecular[i + j] >= '0' and molecular[i + j] <= '9':
            temp = temp * 10 + int(molecular[i + j])
            j = j + 1
        atoms[1] += temp
        i += j

    elif molecular[i] == 'O':
        j = 1
        temp = 0
        while i + j < length and molecular[i + j] >= '0' and molecular[i + j] <= '9':
            temp = temp * 10 + int(molecular[i + j])
            j = j + 1
        atoms[2] += temp
        i += j

    elif molecular[i] == 'N':
        j = 1
        temp = 0
        while i + j < length and molecular[i + j] >= '0' and molecular[i + j] <= '9':
            temp = temp * 10 + int(molecular[i + j])
            j = j + 1
        atoms[3] += temp
        i += j
    else:
        i += 1

mass = 12 * atoms[0] + atoms[1] + 16 * atoms[2] + 14 * atoms[3]
print("The standard molecular formula is:\n    ", end="")
if atoms[0] != 0:
    print("C", end="")
    print(atoms[0], end= "")
if atoms[1] != 0:
    print(" H", end="")
    print(atoms[1], end= "")
if atoms[2] != 0:
    print(" O", end="")
    print(atoms[2], end= "")
if atoms[3] != 0:
    print(" N", end="")
    print(atoms[3], end= "")
print("\nThe molecular weight is: ", end="")
print(mass)
```

#### 输入

标准的分子式，仅含有 C、H、O、N 与数字，不区分大小写，不应有其他字符（如空格），不要求相同原子的数目合并。

#### 输出

标准的分子式，以及其对应的相对分子质量。仅输出分子式中包含的元素。

#### 示例

```
Example 1:
Please input the molecular formula 
[input]:C63H103O65N17
The standard molecular formula is:
    C63 H103 O65 N17
The molecular weight is: 2137

Example 2:
Please input the molecular formula 
[input]:c2h5ohc6h12o6
// 输入时没有进行元素合并，输出会自动整合。
The standard molecular formula is:
    C8 H17 O6
The molecular weight is: 209

Example 3:
Please input the molecular formula 
[input]:n2
The standard molecular formula is:
     N2								
     // 仅含有氮元素
The molecular weight is: 28
```

