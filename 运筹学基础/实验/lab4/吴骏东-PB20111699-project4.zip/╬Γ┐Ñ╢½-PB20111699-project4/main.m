clc;
clear;
close all;

lamda = input("请输入 Lamda:");
mu = input("请输入 Mu:");
c = input("请输入 C:");
N = input("请输入 N:");

P = zeros(1,N + 1);
rho = lamda/(c * mu); 
sum = 0;
for i = 0 : c
    sum = sum + 1/(factorial(i))*(lamda/mu)^i;
end
P(1, 1) = 1/(sum + c^c/factorial(c)* rho * (rho^c - rho^N)/(1-rho));

for i = 1 : c
    P(1, i + 1) = 1/factorial(i) * (lamda / mu)^i * P(1, 1);
end
for i = c + 1 : N
    P(1, i + 1) = c^c/factorial(c) * rho^i * P(1, 1);
end

Lq = P(1,1)*rho*(lamda/mu)^c/(factorial(c)*(1-rho)^2)*(1-rho^(N-c)-(N-c)*rho^(N-c)*(1-rho));
Ls = Lq + lamda/mu * (1- P(1, N+1));
Wq = 1/lamda*Lq/(1-P(1, N+1));
Ws = Wq + 1/mu;

disp("系统空闲概率：");
disp(P(1,1));
disp("系统中有不同人数的概率：");
disp(P(1, 2:N+1));
disp("平均队长：");
disp(Ls);
disp("平均等待队长：");
disp(Lq);
disp("平均逗留时间：");
disp(Ws);
disp("平均等待时间：");
disp(Wq);
 