% 闭回路搜索函数
function flag = search(x0, y0, dest);
% tag 为记录已找过的位置
% x, y为输入坐标
% targetX, Y 为目标坐标
% Path 为记录到的路径
% Base 为基变量标记矩阵
% dest 为调用时的方向， 0- none, 1-up, 2-left, 3-down, 4-right

global tag;
global targetX;
global targetY;
global Base;
global checkflag;
global Path;
global counter;
counter = counter + 1;
s = size(Base);

Path = [Path; {'x', x0, 'y', y0}];
% 路径中添加当前坐标
tag(x0, y0) = 1;
% 标记为已访问
if checkflag && x0 == targetX && y0 == targetY
    flag = 1;
    return;
end
checkflag = 1;
x = x0;
y = y0;
if counter >= 3 && x - 1 == targetX && y == targetY
    flag = 1;
    return 
end
if (x > 1 && tag(x-1, y) == 0)  % 向上搜索

    while (x > 1 && Base(x-1, y) == 0)
        x = x - 1;
    end
    if (~(x <= 1 || tag(x-1, y) == 1))
        % 此时上方为没有访问过的基变量
        if dest ~= 1
            flag = search(x-1, y, 1);
            if (flag == 1)
                return
            end        
        else
            Path(end, :) = [];
            flag = search(x-1, y, 1);
            if (flag == 1)
                return
            end  
            Path = [Path; {'x', x0, 'y', y0}];
        end
    end
end

x = x0;
y = y0;
if counter >= 3 && x  == targetX && y - 1 == targetY
    flag = 1;
    return 
end
if (y > 1 && tag(x, y - 1) == 0)  % 向左搜索
    while (y > 1 && Base(x, y-1) == 0)
        y = y - 1;
    end

    if (~(y <= 1 || tag(x, y-1) == 1))
        % 此时左侧为没有访问过的基变量
        if dest ~= 2
            flag = search(x, y - 1, 2);
            if (flag == 1)
                return
            end
        else
            Path(end, :) = [];
            flag = search(x, y - 1, 2);
            if (flag == 1)
                return
            end
            Path = [Path; {'x', x0, 'y', y0}];
        end
    end
end

x = x0;
y = y0;
if counter >= 3 && x+1  == targetX && y == targetY
    flag = 1;
    return 
end
if (x < s(1) && tag(x+1, y) == 0)  % 向下搜索

    while (x < s(1) && Base(x+1, y) == 0)
        x = x + 1;
    end
    if (~(x >= s(1) || tag(x+1, y) == 1))
        % 此时下方为没有访问过的基变量
        if dest ~= 3
            flag = search(x+1, y, 3);
            if (flag == 1)
                return
            end
        else
            Path(end, :) = [];
            flag = search(x+1, y, 3);
            if (flag == 1)
                return
            end
            Path = [Path; {'x', x0, 'y', y0}];
        end
    end
end

x = x0;
y = y0;
if counter >= 3 && x  == targetX && y + 1 == targetY
    flag = 1;
    return 
end
if (y < s(2) && tag(x, y + 1) == 0)  % 向右搜索

    while (y < s(2) && Base(x, y+1) == 0)
        y = y + 1;
    end
    if (~(y >= s(2) || tag(x, y + 1) == 1))
        % 此时上方为没有访问过的基变量
        if dest ~= 4
            flag = search(x, y + 1, 4);
            if (flag == 1)
                return
            end
        else
            Path(end, :) = [];
            flag = search(x, y + 1, 4);
            if (flag == 1)
                return
            end
            Path = [Path; {'x', x0, 'y', y0}];
        end
    end
end

% 四个方向都没有找到，为无解
Path(end, :) = [];
% 删除当前的路径末尾
tag(x0, y0) = 0;
flag = 0;
return




