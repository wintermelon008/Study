% Input: original support and need 
% [ 10, 5, 6, 7, 2500;
%   8, 2, 7, 6, 2500;
%   9, 3, 4, 8, 5000;
%   1500, 2000, 3000, 3500, 0]
clear;
clc;
A = input("请输入原始供求矩阵");
s = size(A);    
global Path;
global targetX;
global targetY;
global tag;
global checkflag;
global counter;
need = A(s(1), :);      % 最后一行
supply = A(:, s(2));    % 最后一列
clm_sub = zeros(1, s(2) - 1); %行差顺
row_sub = zeros(1, s(1) - 1); %列差顺

for j = 1: 1: s(2)-1
    B = sortrows(A, j);
    clm_sub(1, j) = B(2, j) - B(1, j);
end

B = sort(A, 2);
for i = 1 : 1: s(1)-1
    row_sub(1, i) = B(i, 2) - B(i, 1);
end

% 计算初始可行解
counter = 0;
row_available = ones(1, s(1) - 1);
clm_available = ones(1, s(2) - 1);
initial_ans = A;
for i = 1 : 1: s(1)-1
    for j = 1: 1: s(2)-1
        initial_ans(i, j) = 0;
    end
end
baseX = zeros(1, s(1) + s(2) - 3);
baseY = zeros(1, s(1) + s(2) - 3);
k = 1;
% (baseX(k), baseY(k))为基变量 x_baseX(k)_baseY(k)
global Base;
Base = zeros(s(1) - 1, s(2) - 1);
while (counter < s(1) + s(2) - 3)
    counter = counter + 1;
    row = 0;
    clm = 0;
    row_max_data = 0;
    row_max_address = 0;
    clm_max_data = 0;
    clm_max_address = 0;
    for i = 1 : 1 : s(1) - 1
        if (row_available(1, i) && row_sub(1, i) > row_max_data)
            row_max_data = row_sub(1, i);
            row_max_address = i;
        end
    end
    for i = 1 : 1 : s(2) - 1
        if (clm_available(1, i) && clm_sub(1, i) > clm_max_data)
            clm_max_data = clm_sub(1, i);
            clm_max_address = i;
        end
    end
    %[row_max_data, row_max_address] = max(row_sub, [], 2);
    %[clm_max_data, clm_max_address] = max(clm_sub, [], 2);
    if (row_max_data > clm_max_data)
        max_data = row_max_data;
        max_address = row_max_address;
        row = 1;
    else
        max_data = clm_max_data;
        max_address = clm_max_address;
        clm = 1;
    end
    
    if row == 1
        number = 0;
        address = 0;
        for i = 1: 1: s(2) - 1
            if (clm_available(1, i) == 1 && A(max_address, i) > number)
                number = A(max_address, i);
                address = i;
            end
        end
       %[number , address] = max(A(max_address, 1:s(2) - 1), [], 2);
        % 找到这一行最大元素        
        add_num = min(initial_ans(s(1), address), initial_ans(max_address, s(2)));
        initial_ans(s(1), address) = initial_ans(s(1), address) - add_num;
        initial_ans(max_address, s(2)) = initial_ans(max_address, s(2)) - add_num;
        initial_ans(max_address, address) = initial_ans(max_address, address) + add_num;
        baseX(k) = max_address;
        baseY(k) = address;
        Base(max_address, address) = 1;
        k = k + 1;
        if initial_ans(s(1), address) == 0
            clm_available(1, address) = 0;
        else
            row_available(1, max_address) = 0;
        end
    else
        number = 0;
        address = 0;
        for i = 1: 1: s(1) - 1
            if (row_available(1, i) == 1 && A(i, max_address) > number)
                number = A(i, max_address);
                address = i;
            end
        end
       %[number , address] = max(A(max_address, 1:s(2) - 1), [], 2);
        % 找到这一列最大元素        
        add_num = min(initial_ans(s(1), max_address), initial_ans(address, s(2)));
        initial_ans(s(1), max_address) = initial_ans(s(1),max_address) - add_num;
        initial_ans(address, s(2)) = initial_ans(address, s(2)) - add_num;
        initial_ans(address, max_address) = initial_ans(address, max_address) + add_num;
        baseX(k) = address;
        baseY(k) = max_address;
        Base(address, max_address) = 1;
        k = k + 1;
        if initial_ans(s(1), max_address) == 0
            clm_available(1, max_address) = 0;
        else
            row_available(1, address) = 0;
        end
    end 
end
% 得到初始可行解
times = 0;
current_ans = initial_ans;
while(times < 50)
    % 迭代开始
    funcA = zeros(1, s(1) + s(2) - 2);
    funcA(1, 1) = 1;
    funcb = zeros(1, 1);

    % 开始求解方程组
    for k = 1: 1: s(1) + s(2) - 3
        new_row = zeros(1, s(1) + s(2) - 2);
        new_row(1, baseX(k)) = 1;
        new_row(1, s(1) - 1 + baseY(k)) = 1;
        funcA = [funcA; new_row];
        new_b = A(baseX(k), baseY(k));
        funcb = [funcb; new_b];
    end

    funcans = funcA \ funcb;
    max = 0;
    in_X = 0;
    in_Y = 0;
    for i = 1: 1: s(1) - 1
        for j = 1: 1: s(2) - 1
            temp = A(i, j) - funcans(i) - funcans(j + s(1) - 1);
            if (temp > 0 && temp > max)
                in_X = i;
                in_Y = j;
                max = temp;
            end
        end
    end
    if max == 0
        % 找到最优解
        disp(current_ans);
        Z = 0;
        for i = 1: 1: s(1) - 1
            for j = 1: 1: s(2) - 1
                if Base(i, j) == 1
                    Z = Z + A(i, j) * current_ans(i, j);
                end
            end
        end
        disp(Z);
        return
    end
    % 确定换入变量 in(x, y)
    % 开始闭回路调整法

    counter = 0;
    checkflag = 0;
    Path = [];
    targetX = in_X;
    targetY = in_Y;
    tag = zeros(s(1) - 1, s(2) - 1);
    tag(in_X, in_Y) = 1;
    search(in_X, in_Y, 0);

    % 现在 path 中存储找到的闭回路

    length = size(Path);
    min = 9999;
    min_address = 0;
    for i = 2: 2: length(1)
        if current_ans(Path{i, 2}, Path{i, 4}) < min
            x = Path{i, 2};
            y = Path{i, 4};
            min_address = i;
            min = current_ans(Path{i, 2}, Path{i, 4});
        end
    end
    Base(in_X, in_Y) = 1;
    Base(Path{min_address, 2},Path{min_address, 4}) = 0;
    % 修改当前解
    for i = 1: 1:length(1)
        if (mod(i , 2) == 1)
            current_ans(Path{i, 2}, Path{i, 4}) = current_ans(Path{i, 2}, Path{i, 4}) + min;
        else
            current_ans(Path{i, 2}, Path{i, 4}) = current_ans(Path{i, 2}, Path{i, 4}) - min;
        end
    end
    % 更换基变量
    k = 1;
    for i = 1: 1: s(1) - 1
        for j = 1: 1: s(2) - 1
            if Base(i, j) == 1
                baseX(k) = i;
                baseY(k) = j;
                k = k + 1;
            end
        end
    end
    % 进行下一次迭代
    times = times + 1;
end

