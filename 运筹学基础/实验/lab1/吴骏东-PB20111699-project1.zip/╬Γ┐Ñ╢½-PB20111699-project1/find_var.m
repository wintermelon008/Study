function X_new = find_var(X_last)
% 函数通过矩阵A输入单纯形表内容，通过X_last指定的基变量进行计算
% 输入：当前的基变量编号，按照矩阵形式输入 e.g. [1 2 4 6]
% 返回：新的基变量编号
% A 的第一行为价值系数
% A 的第一列为bi(>=0)
global A
s = [0 0];
s = size(A);            % 获取矩阵的大小, s = [x, y] x行 y 列

check = zeros(1,s(2) - 1);     % 初始化检验数
flag = 1;
max = 0;
max_clm = 0;
for i = 2: 1: s(2)    
    check(1,i - 1) = A(1,i);
    for j = 2: 1: s(1)
        check(1,i - 1) = check(1,i - 1) - A(j,i) * A(1,X_last(j - 1) + 1);
    end
    if check(1,i - 1) > 0
        flag = 0;
    end
    if (max < check(1,i - 1))
        max = check(1,i - 1);
        max_clm = i;        % 记录检验数最大值所在列
    end
end
%todo 没有考虑无界解的问题

if (max_clm == 0 ||flag == 1) %所有的检验数均为负数，表明单纯形计算已经结束
    X_new = X_last;
    disp(check);
    return
end
% todo 没有考虑可行解问题


theta = zeros(1,s(1) - 1);      % 初始化 theta 规则数
min = 9999900;
min_row = 0;
for i = 2: 1: s(1)
    if (A(i, max_clm) > 0)      %仅在该行系数为正时进行计算
        % 注意：此时A(i, 1)即bi一定非负！
        theta(1, i - 1) = A(i, 1) / A(i, max_clm); 
        if (theta(1, i - 1) >= 0) && (min > theta(1, i - 1))
            min = theta(1, i - 1);
            min_row = i;    % 记录 theta 规则最小的一行
        end
    end
end

% 确定了主变量位置为(min_row, max_clm)
% 接下来开始迭代运算

X_new = X_last;
X_new(min_row - 1) = max_clm - 1; % 更换基变量
temp = A(min_row, max_clm);

for i = 1: 1: s(2)    % 该行单位化
    A(min_row, i) = A(min_row, i) / temp;
end

for i = 2: 1: s(1)
    if (A(i, max_clm) ~= 0) && (i ~= min_row) 
        temp1 = A(i, max_clm);
        for j = 1: 1: s(2)
            A(i, j) = A(i, j) - A(min_row, j) * temp1;
        end
    end
end


