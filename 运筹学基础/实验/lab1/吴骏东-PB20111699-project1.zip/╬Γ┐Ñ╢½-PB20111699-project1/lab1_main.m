global A;
format long%;
A = input('请输入单纯性矩阵');
X_last = input('请输入当前基变量');
flag = true;
times = 1;
while flag == true && times <= 50
    X_new = find_var(X_last);
    times = times + 1;
    if X_new == X_last
        flag = false;
    else
        X_last = X_new;
    end
    disp('次数：');
    disp(times);
    disp(X_last);
end
if times > 50
    disp('计算超时');
end
disp('求解结果为：');
disp(A);
disp('基变量为：');
disp(X_new);
sum = 0;
s = [0 0];
s = size(A);
for i = 2:1:s(1)
    sum = sum + A(1, X_new(1, i - 1) + 1) * A(i, 1);
end
disp('MAX=');
disp(sum);

% [0 2 3 0 0 0;8 1 2 1 0 0;16 4 0 0 1 0;12 0 4 0 0 1]
% [3 4 5]

%  [0 0.9 1.4  1.9 0.45 0.95  1.45 -0.05 0.45  0.95  0  0 0 0  0 0 0 0 ;
%   0 -0.4 0.6  0.6 0 0  0 0 0  0  1  0 0 0  0 0 0 0 ;
%   0 -0.2 -0.2  0.8 0 0  0 0 0  0 0   1 0 0  0 0 0 0;
%   0 0 0  0 -0.85 0.15  0.15 0 0  0 0   0 1 0  0 0 0 0 ;
%   0 0 0  0 -0.6 -0.6  0.4 0 0  0 0 0   0 1  0 0 0 0;
%   0 0 0  0 0 0  0 -0.5 -0.5  0.5 0 0   0 0  1 0 0 0;
%   2000 1 0  0 1 0  0 1 0  0 0 0  0 0   0 1 0 0;
%   2500 0 1  0 0 1  0 0 1  0 0 0  0 0   0 0 1 0;
%   1200 0 0  1 0 0  1 0 0  1 0 0  0 0   0 0 0 1]

%[10 11 12 13 14 15 16 17]
